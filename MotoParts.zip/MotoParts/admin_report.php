<?php
// admin_report.php - Business Report for Admin Only

require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

session_start();
include 'config.php';

// Admin-only authentication
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Check if export is requested
if (isset($_GET['export'])) {
    $format = $_GET['format'] ?? 'pdf';
    exportReport($conn, $format);
    exit();
}

// Fetch comprehensive business data
$businessData = getBusinessData($conn);

function getBusinessData($conn) {
    $data = [];
    
    // 1. Total Sales and Revenue
    $sales_query = "SELECT 
        COUNT(*) as total_orders,
        SUM(total_price) as total_revenue,
        AVG(total_price) as avg_order_value,
        SUM(quantity) as total_items_sold
        FROM orders";
    $sales_result = mysqli_query($conn, $sales_query);
    $data['sales_summary'] = mysqli_fetch_assoc($sales_result);
    
    // 2. Sales by Product
    $product_sales_query = "SELECT 
        product_name,
        COUNT(*) as order_count,
        SUM(quantity) as total_sold,
        SUM(total_price) as revenue,
        AVG(total_price) as avg_price
        FROM orders 
        GROUP BY product_name
        ORDER BY revenue DESC";
    $product_sales_result = mysqli_query($conn, $product_sales_query);
    $data['product_sales'] = [];
    while ($row = mysqli_fetch_assoc($product_sales_result)) {
        $data['product_sales'][] = $row;
    }
    
    // 3. Sales by Category (based on product name patterns)
    $category_query = "SELECT 
        CASE 
            WHEN product_name LIKE '%tire%' OR product_name LIKE '%wheel%' THEN 'Tires & Wheels'
            WHEN product_name LIKE '%brake%' THEN 'Brakes'
            WHEN product_name LIKE '%engine%' OR product_name LIKE '%motor%' THEN 'Engine Parts'
            WHEN product_name LIKE '%oil%' OR product_name LIKE '%fluid%' THEN 'Oils & Fluids'
            WHEN product_name LIKE '%chain%' OR product_name LIKE '%belt%' THEN 'Drive Components'
            WHEN product_name LIKE '%suspension%' OR product_name LIKE '%shock%' THEN 'Suspension'
            WHEN product_name LIKE '%battery%' OR product_name LIKE '%electrical%' THEN 'Electrical'
            ELSE 'General Parts'
        END as category,
        COUNT(*) as order_count,
        SUM(quantity) as total_sold,
        SUM(total_price) as revenue
        FROM orders 
        GROUP BY category
        ORDER BY revenue DESC";
    $category_result = mysqli_query($conn, $category_query);
    $data['category_sales'] = [];
    while ($row = mysqli_fetch_assoc($category_result)) {
        $data['category_sales'][] = $row;
    }
    
    // 4. Monthly Trends (last 12 months)
    $trends_query = "SELECT 
        DATE_FORMAT(order_date, '%Y-%m') as month,
        COUNT(*) as order_count,
        SUM(total_price) as revenue,
        SUM(quantity) as items_sold
        FROM orders 
        WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
        GROUP BY DATE_FORMAT(order_date, '%Y-%m')
        ORDER BY month ASC";
    $trends_result = mysqli_query($conn, $trends_query);
    $data['monthly_trends'] = [];
    while ($row = mysqli_fetch_assoc($trends_result)) {
        $data['monthly_trends'][] = $row;
    }
    
    // 5. Customer Analytics
    $customer_query = "SELECT 
        customer_email,
        COUNT(*) as order_count,
        SUM(total_price) as total_spent,
        AVG(total_price) as avg_order_value,
        MAX(order_date) as last_order_date
        FROM orders 
        GROUP BY customer_email
        ORDER BY total_spent DESC
        LIMIT 10";
    $customer_result = mysqli_query($conn, $customer_query);
    $data['top_customers'] = [];
    while ($row = mysqli_fetch_assoc($customer_result)) {
        $data['top_customers'][] = $row;
    }
    
    // 6. Order Status Analytics
    $status_query = "SELECT 
        order_status,
        COUNT(*) as count,
        SUM(total_price) as revenue
        FROM orders 
        GROUP BY order_status";
    $status_result = mysqli_query($conn, $status_query);
    $data['order_status'] = [];
    while ($row = mysqli_fetch_assoc($status_result)) {
        $data['order_status'][] = $row;
    }
    
    // 7. Payment Method Analytics
    $payment_query = "SELECT 
        payment_method,
        COUNT(*) as count,
        SUM(total_price) as revenue
        FROM orders 
        GROUP BY payment_method";
    $payment_result = mysqli_query($conn, $payment_query);
    $data['payment_methods'] = [];
    while ($row = mysqli_fetch_assoc($payment_result)) {
        $data['payment_methods'][] = $row;
    }
    
    return $data;
}

function exportReport($conn, $format) {
    $data = getBusinessData($conn);
    
    if ($format === 'excel') {
        exportToExcel($data);
    } else {
        exportToPDF($data);
    }
}

function exportToExcel($data) {
    try {
        $spreadsheet = new Spreadsheet();
        
        // Summary Sheet
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle("Business Summary");
        
        // Headers and styling
        $headerStyle = [
            'font' => [
                'bold' => true,
                'size' => 12,
                'color' => ['rgb' => 'FFFFFF']
            ],
            'fill' => [
                'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                'startColor' => ['rgb' => '4472C4']
            ]
        ];
        
        // Business Summary
        $sheet->setCellValue('A1', 'BUSINESS REPORT - ' . date('Y-m-d'));
        $sheet->getStyle('A1')->applyFromArray($headerStyle);
        $sheet->mergeCells('A1:D1');
        
        $row = 3;
        $sheet->setCellValue("A{$row}", 'SALES SUMMARY');
        $sheet->getStyle("A{$row}")->applyFromArray($headerStyle);
        $sheet->mergeCells("A{$row}:D{$row}");
        
        $row++;
        $sheet->setCellValue("A{$row}", 'Total Orders');
        $sheet->setCellValue("B{$row}", $data['sales_summary']['total_orders']);
        $row++;
        $sheet->setCellValue("A{$row}", 'Total Revenue');
        $sheet->setCellValue("B{$row}", '$' . number_format($data['sales_summary']['total_revenue'], 2));
        $row++;
        $sheet->setCellValue("A{$row}", 'Average Order Value');
        $sheet->setCellValue("B{$row}", '$' . number_format($data['sales_summary']['avg_order_value'], 2));
        $row++;
        $sheet->setCellValue("A{$row}", 'Total Items Sold');
        $sheet->setCellValue("B{$row}", $data['sales_summary']['total_items_sold']);
        
        // Product Sales Sheet
        $productSheet = $spreadsheet->createSheet();
        $productSheet->setTitle("Product Sales");
        
        $productSheet->setCellValue('A1', 'Product Name');
        $productSheet->setCellValue('B1', 'Orders');
        $productSheet->setCellValue('C1', 'Quantity Sold');
        $productSheet->setCellValue('D1', 'Revenue');
        $productSheet->setCellValue('E1', 'Avg Price');
        $productSheet->getStyle('A1:E1')->applyFromArray($headerStyle);
        
        $row = 2;
        foreach ($data['product_sales'] as $product) {
            $productSheet->setCellValue("A{$row}", $product['product_name']);
            $productSheet->setCellValue("B{$row}", $product['order_count']);
            $productSheet->setCellValue("C{$row}", $product['total_sold']);
            $productSheet->setCellValue("D{$row}", '$' . number_format($product['revenue'], 2));
            $productSheet->setCellValue("E{$row}", '$' . number_format($product['avg_price'], 2));
            $row++;
        }
        
        // Category Sales Sheet
        $categorySheet = $spreadsheet->createSheet();
        $categorySheet->setTitle("Category Sales");
        
        $categorySheet->setCellValue('A1', 'Category');
        $categorySheet->setCellValue('B1', 'Orders');
        $categorySheet->setCellValue('C1', 'Quantity Sold');
        $categorySheet->setCellValue('D1', 'Revenue');
        $categorySheet->getStyle('A1:D1')->applyFromArray($headerStyle);
        
        $row = 2;
        foreach ($data['category_sales'] as $category) {
            $categorySheet->setCellValue("A{$row}", $category['category']);
            $categorySheet->setCellValue("B{$row}", $category['order_count']);
            $categorySheet->setCellValue("C{$row}", $category['total_sold']);
            $categorySheet->setCellValue("D{$row}", '$' . number_format($category['revenue'], 2));
            $row++;
        }
        
        // Auto-size columns for all sheets
        foreach ($spreadsheet->getAllSheets() as $worksheet) {
            foreach (range('A', $worksheet->getHighestColumn()) as $col) {
                $worksheet->getColumnDimension($col)->setAutoSize(true);
            }
        }
        
        // Output Excel file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="business_report_' . date('Y-m-d') . '.xlsx"');
        header('Cache-Control: max-age=0');
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        
    } catch (Exception $e) {
        die("Error generating Excel file: " . $e->getMessage());
    }
}

function exportToPDF($data) {
    try {
        $pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        
        $pdf->SetCreator('MotoParts Manager');
        $pdf->SetAuthor('Admin');
        $pdf->SetTitle('Business Report');
        $pdf->SetSubject('Business Analytics Report');
        
        $pdf->SetHeaderData('', 0, 'Business Report', 'Generated on ' . date('Y-m-d H:i:s'));
        $pdf->setFooterData();
        
        $pdf->SetMargins(15, PDF_MARGIN_TOP, 15);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
        
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 10);
        
        // Build HTML content
        $html = '<h1 style="text-align: center; color: #333;">Business Analytics Report</h1>';
        $html .= '<p style="text-align: center;"><strong>Generated:</strong> ' . date('Y-m-d H:i:s') . '</p>';
        
        // Sales Summary
        $html .= '<h2 style="color: #4472C4;">Sales Summary</h2>';
        $html .= '<table border="1" cellpadding="5" cellspacing="0" style="width: 100%;">';
        $html .= '<tr style="background-color: #f0f0f0;">';
        $html .= '<td><strong>Total Orders</strong></td><td>' . $data['sales_summary']['total_orders'] . '</td>';
        $html .= '</tr>';
        $html .= '<tr>';
        $html .= '<td><strong>Total Revenue</strong></td><td>$' . number_format($data['sales_summary']['total_revenue'], 2) . '</td>';
        $html .= '</tr>';
        $html .= '<tr style="background-color: #f0f0f0;">';
        $html .= '<td><strong>Average Order Value</strong></td><td>$' . number_format($data['sales_summary']['avg_order_value'], 2) . '</td>';
        $html .= '</tr>';
        $html .= '<tr>';
        $html .= '<td><strong>Total Items Sold</strong></td><td>' . $data['sales_summary']['total_items_sold'] . '</td>';
        $html .= '</tr>';
        $html .= '</table><br>';
        
        // Top Products
        $html .= '<h2 style="color: #4472C4;">Top Products by Revenue</h2>';
        $html .= '<table border="1" cellpadding="3" cellspacing="0" style="width: 100%; font-size: 9px;">';
        $html .= '<tr style="background-color: #4472C4; color: white;">';
        $html .= '<th>Product</th><th>Orders</th><th>Qty Sold</th><th>Revenue</th>';
        $html .= '</tr>';
        
        $count = 0;
        foreach ($data['product_sales'] as $product) {
            if ($count >= 10) break; // Top 10 only for PDF
            $html .= '<tr' . (($count % 2 == 0) ? ' style="background-color: #f9f9f9;"' : '') . '>';
            $html .= '<td>' . htmlspecialchars($product['product_name']) . '</td>';
            $html .= '<td>' . $product['order_count'] . '</td>';
            $html .= '<td>' . $product['total_sold'] . '</td>';
            $html .= '<td>$' . number_format($product['revenue'], 2) . '</td>';
            $html .= '</tr>';
            $count++;
        }
        $html .= '</table><br>';
        
        // Category Sales
        $html .= '<h2 style="color: #4472C4;">Sales by Category</h2>';
        $html .= '<table border="1" cellpadding="3" cellspacing="0" style="width: 100%; font-size: 9px;">';
        $html .= '<tr style="background-color: #4472C4; color: white;">';
        $html .= '<th>Category</th><th>Orders</th><th>Qty Sold</th><th>Revenue</th>';
        $html .= '</tr>';
        
        $count = 0;
        foreach ($data['category_sales'] as $category) {
            $html .= '<tr' . (($count % 2 == 0) ? ' style="background-color: #f9f9f9;"' : '') . '>';
            $html .= '<td>' . htmlspecialchars($category['category']) . '</td>';
            $html .= '<td>' . $category['order_count'] . '</td>';
            $html .= '<td>' . $category['total_sold'] . '</td>';
            $html .= '<td>$' . number_format($category['revenue'], 2) . '</td>';
            $html .= '</tr>';
            $count++;
        }
        $html .= '</table>';
        
        $pdf->writeHTML($html, true, false, true, false, '');
        $pdf->Output('business_report_' . date('Y-m-d') . '.pdf', 'D');
        
    } catch (Exception $e) {
        die("Error generating PDF file: " . $e->getMessage());
    }
}

$data = $businessData;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Report - MotoParts Manager</title>
    <link rel="stylesheet" href="adminstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .report-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .report-header {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, #4472C4, #70AD47);
            color: white;
            border-radius: 10px;
        }
        .export-buttons {
            text-align: center;
            margin: 20px 0;
        }
        .export-btn {
            display: inline-block;
            padding: 12px 24px;
            margin: 0 10px;
            background: #4472C4;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.3s;
        }
        .export-btn:hover {
            background: #365899;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .stat-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            border-left: 4px solid #4472C4;
        }
        .stat-value {
            font-size: 2em;
            font-weight: bold;
            color: #4472C4;
        }
        .chart-container {
            margin: 30px 0;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .data-table th, .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .data-table th {
            background: #4472C4;
            color: white;
        }
        .data-table tr:nth-child(even) {
            background: #f9f9f9;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="navdiv">
            <div class="logo">
                <img src="assets/logo.jpg" alt="MotoParts Manager">
            </div>
            <ul style="padding-top: 20px; padding-right: 20px;">
                <li><a class="hac" href="adminpage.php">Dashboard</a></li>
                <li><a class="hac active" href="#">Business Report</a></li>
                <li><a class="hac" href="about_admin.html">About</a></li>
                <div class="navbar2">
                    <a href="logout.php" style="color: black; font-weight: bold;">Log Out</a> 
                </div>
            </ul>
        </div>
    </nav>

    <div class="report-container">
        <div class="report-header">
            <h1><i class='bx bx-bar-chart-alt-2'></i> Business Analytics Report</h1>
            <p>Comprehensive business insights and trends</p>
            <p><strong>Generated:</strong> <?php echo date('F j, Y - g:i A'); ?></p>
        </div>

        <!-- Export Buttons -->
        <div class="export-buttons">
            <a href="?export=1&format=pdf" class="export-btn">
                <i class='bx bxs-file-pdf'></i> Export PDF
            </a>
            <a href="?export=1&format=excel" class="export-btn">
                <i class='bx bxs-file-export'></i> Export Excel
            </a>
        </div>

        <!-- Sales Summary -->
        <h2><i class='bx bx-trending-up'></i> Sales Summary</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($data['sales_summary']['total_orders']); ?></div>
                <div>Total Orders</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$<?php echo number_format($data['sales_summary']['total_revenue'], 2); ?></div>
                <div>Total Revenue</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$<?php echo number_format($data['sales_summary']['avg_order_value'], 2); ?></div>
                <div>Average Order Value</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($data['sales_summary']['total_items_sold']); ?></div>
                <div>Items Sold</div>
            </div>
        </div>

        <!-- Monthly Trends Chart -->
        <?php if (!empty($data['monthly_trends'])): ?>
        <div class="chart-container">
            <h3><i class='bx bx-line-chart'></i> Monthly Revenue Trends</h3>
            <canvas id="trendsChart" width="400" height="200"></canvas>
        </div>
        <?php endif; ?>

        <!-- Category Sales Chart -->
        <?php if (!empty($data['category_sales'])): ?>
        <div class="chart-container">
            <h3><i class='bx bx-pie-chart-alt-2'></i> Sales by Category</h3>
            <canvas id="categoryChart" width="400" height="200"></canvas>
        </div>
        <?php endif; ?>

        <!-- Product Sales Table -->
        <h3><i class='bx bx-package'></i> Top Products by Revenue</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Orders</th>
                    <th>Quantity Sold</th>
                    <th>Revenue</th>
                    <th>Avg Price</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (array_slice($data['product_sales'], 0, 10) as $product): ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                    <td><?php echo $product['order_count']; ?></td>
                    <td><?php echo $product['total_sold']; ?></td>
                    <td>$<?php echo number_format($product['revenue'], 2); ?></td>
                    <td>$<?php echo number_format($product['avg_price'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Category Sales Table -->
        <h3><i class='bx bx-category'></i> Sales by Category</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Orders</th>
                    <th>Quantity Sold</th>
                    <th>Revenue</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['category_sales'] as $category): ?>
                <tr>
                    <td><?php echo htmlspecialchars($category['category']); ?></td>
                    <td><?php echo $category['order_count']; ?></td>
                    <td><?php echo $category['total_sold']; ?></td>
                    <td>$<?php echo number_format($category['revenue'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Top Customers -->
        <?php if (!empty($data['top_customers'])): ?>
        <h3><i class='bx bx-user-check'></i> Top Customers</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Customer Email</th>
                    <th>Orders</th>
                    <th>Total Spent</th>
                    <th>Avg Order Value</th>
                    <th>Last Order</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['top_customers'] as $customer): ?>
                <tr>
                    <td><?php echo htmlspecialchars($customer['customer_email']); ?></td>
                    <td><?php echo $customer['order_count']; ?></td>
                    <td>$<?php echo number_format($customer['total_spent'], 2); ?></td>
                    <td>$<?php echo number_format($customer['avg_order_value'], 2); ?></td>
                    <td><?php echo $customer['last_order_date']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <script>
        // Monthly Trends Chart
        <?php if (!empty($data['monthly_trends'])): ?>
        const trendsCtx = document.getElementById('trendsChart').getContext('2d');
        new Chart(trendsCtx, {
            type: 'line',
            data: {
                labels: [<?php echo "'" . implode("','", array_column($data['monthly_trends'], 'month')) . "'"; ?>],
                datasets: [{
                    label: 'Revenue',
                    data: [<?php echo implode(',', array_column($data['monthly_trends'], 'revenue')); ?>],
                    borderColor: '#4472C4',
                    backgroundColor: 'rgba(68, 114, 196, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
        <?php endif; ?>

        // Category Sales Chart
        <?php if (!empty($data['category_sales'])): ?>
        const categoryCtx = document.getElementById('categoryChart').getContext('2d');
        new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: [<?php echo "'" . implode("','", array_column($data['category_sales'], 'category')) . "'"; ?>],
                datasets: [{
                    data: [<?php echo implode(',', array_column($data['category_sales'], 'revenue')); ?>],
                    backgroundColor: [
                        '#4472C4', '#70AD47', '#FFC000', '#C55A5A', '#7030A0',
                        '#00B0F0', '#92D050', '#FF6600', '#A5A5A5', '#375623'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>
