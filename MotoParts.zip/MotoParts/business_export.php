<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;

session_start();
include 'config.php';

if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    die("Unauthorized access");
}

$format = $_GET['format'] ?? 'pdf';

// Fetch sales by product
$salesByProductQuery = "SELECT tracking_number, product_name, SUM(quantity) AS total_quantity, SUM(total_price) AS total_sales FROM orders GROUP BY tracking_number, product_name";
$salesByProductResult = $conn->query($salesByProductQuery);
$salesByProduct = [];
while ($row = $salesByProductResult->fetch_assoc()) {
    $salesByProduct[] = $row;
}

// Fetch sales by category (join with inventory to get category)
$salesByCategoryQuery = "SELECT category, SUM(orders.quantity) AS total_quantity, SUM(total_price) AS total_sales FROM orders JOIN inventory ON orders.product_name = inventory.product_name GROUP BY category";
$salesByCategoryResult = $conn->query($salesByCategoryQuery);
$salesByCategory = [];
if ($salesByCategoryResult) {
    while ($row = $salesByCategoryResult->fetch_assoc()) {
        $salesByCategory[] = $row;
    }
}

$conn->close();

if ($format === 'excel') {
    try {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle("Business Sales Report");

        $logoPath = 'assets/logo.jpg';
        if (file_exists($logoPath)) {
            $drawing = new Drawing();
            $drawing->setName('Company Logo');
            $drawing->setDescription('Company Logo');
            $drawing->setPath($logoPath);
            $drawing->setHeight(50);
            $drawing->setCoordinates('B1');
            $drawing->setOffsetX(10);
            $drawing->setOffsetY(5);
            $drawing->setWorksheet($sheet);
        }

        // Header text
        $sheet->setCellValue('A1', 'Business Sales Report');
        $sheet->mergeCells('A1:H1');
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
        $sheet->getStyle('A1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT);

        date_default_timezone_set('Asia/Manila');
        $sheet->setCellValue('A2', 'Generated: ' . date('Y-m-d h:i:s A'));

        // Sales by Product table header
        $sheet->setCellValue('A4', 'Sales by Product');
        $productHeaders = ['Tracking Number', 'Product Name', 'Total Quantity', 'Total Sales'];
        $sheet->fromArray($productHeaders, null, 'A5');

        // Style header row for product table
        $headerStyle = [
            'font' => ['bold' => true, 'color' => ['rgb' => '000000']],
            'fill' => [
                'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E2E8F0']
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    'color' => ['rgb' => '000000']
                ]
            ]
        ];
        $sheet->getStyle('A5:D5')->applyFromArray($headerStyle);

        // Fill sales by product data
        $rowIndex = 6;
        foreach ($salesByProduct as $product) {
            $sheet->setCellValue("A{$rowIndex}", $product['tracking_number']);
            $sheet->setCellValue("B{$rowIndex}", $product['product_name']);
            $sheet->setCellValue("C{$rowIndex}", $product['total_quantity']);
            $sheet->setCellValue("D{$rowIndex}", '₱' . number_format($product['total_sales'], 2));
            $sheet->getStyle("A{$rowIndex}:D{$rowIndex}")->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
            $rowIndex++;
        }

        // Leave a blank row before next table
        $rowIndex += 2;

        // Sales by Category table header
        $sheet->setCellValue("A{$rowIndex}", 'Sales by Category');
        $sheet->getStyle("A{$rowIndex}")->getFont()->setBold(true);
        $rowIndex++;
        $categoryHeaders = ['Category', 'Total Quantity', 'Total Sales'];
        $sheet->fromArray($categoryHeaders, null, "A{$rowIndex}");
        $sheet->getStyle("A{$rowIndex}:C{$rowIndex}")->applyFromArray($headerStyle);

        // Fill sales by category data
        $rowIndex++;
        foreach ($salesByCategory as $category) {
            $sheet->setCellValue("A{$rowIndex}", $category['category']);
            $sheet->setCellValue("B{$rowIndex}", $category['total_quantity']);
            $sheet->setCellValue("C{$rowIndex}", '₱' . number_format($category['total_sales'], 2));
            $sheet->getStyle("A{$rowIndex}:C{$rowIndex}")->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
            $rowIndex++;
        }

        // Auto-size columns
        foreach (range('A', 'H') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        // Set headers for Excel download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="business_sales_report_' . date('Y-m-d_h.iA') . '.xlsx"');
        header('Cache-Control: max-age=0');

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit();

    } catch (Exception $e) {
        die("Error generating Excel file: " . $e->getMessage());
    }
} else {
    // PDF export using TCPDF
    try {
        if (ob_get_level()) {
            ob_end_clean();
        }

        class CustomPDF extends TCPDF {
            public function Header() {
                $logoPath = 'assets/logo.jpg';
                if (file_exists($logoPath)) {
                    $this->Image($logoPath, 10, 10, 30);
                }
                $this->SetFont('helvetica', 'B', 16);
                $this->SetXY(45, 10);
                $this->Cell(100, 10, 'Moto Parts Manager', 0, 1, 'L');
                $this->SetFont('helvetica', '', 10);
                $this->SetX(45);
                $this->Cell(100, 6, 'Business Sales Report', 0, 1, 'L');
                $this->SetFont('helvetica', '', 9);
                $this->SetXY(200, 12);
                $this->Cell(0, 6, 'Admin: ' . $_SESSION['email'], 0, 1, 'R');
                $this->Ln(10);
            }
            public function Footer() {
                $this->SetY(-15);
                $this->SetFont('helvetica', '', 8);
                date_default_timezone_set('Asia/Manila');
                $this->Cell(0, 10, 'Generated: ' . date('Y-m-d h:i:s A'), 0, 0, 'L');
                $this->Cell(0, 10, 'Page ' . $this->getAliasNumPage() . ' of ' . $this->getAliasNbPages(), 0, 0, 'R');
            }
        }

        $pdf = new CustomPDF('L', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        $pdf->SetCreator('Moto Parts Management System');
        $pdf->SetAuthor('Your Company');
        $pdf->SetTitle('Business Sales Report');
        $pdf->SetSubject('Sales Data');

        $pdf->SetMargins(10, 25, 10);
        $pdf->SetHeaderMargin(10);
        $pdf->SetFooterMargin(15);
        $pdf->SetAutoPageBreak(TRUE, 15);

        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 8);

        // Move cursor down to avoid overlapping logo
        $pdf->SetY(45);

        // Build HTML content for sales by product table
        $html = '<h2>Sales by Product</h2>';
        $html .= '<table border="1" cellpadding="4" cellspacing="0" style="width: 100%; font-size: 8px;">';
        $html .= '<thead><tr style="background-color: #E2E8F0; font-weight: bold; color: #000000;">';
        $html .= '<th>Tracking Number</th><th>Product Name</th><th>Total Quantity</th><th>Total Sales</th>';
        $html .= '</tr></thead><tbody>';

        foreach ($salesByProduct as $product) {
            $html .= '<tr>';
            $html .= '<td>' . htmlspecialchars($product['tracking_number']) . '</td>';
            $html .= '<td>' . htmlspecialchars($product['product_name']) . '</td>';
            $html .= '<td style="text-align: center;">' . htmlspecialchars($product['total_quantity']) . '</td>';
            $html .= '<td style="text-align: right;">₱' . number_format($product['total_sales'], 2) . '</td>';
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';

        // Sales by category table
        $html .= '<h2>Sales by Category</h2>';
        $html .= '<table border="1" cellpadding="4" cellspacing="0" style="width: 100%; font-size: 8px;">';
        $html .= '<thead><tr style="background-color: #E2E8F0; font-weight: bold; color: #000000;">';
        $html .= '<th>Category</th><th>Total Quantity</th><th>Total Sales</th>';
        $html .= '</tr></thead><tbody>';

        foreach ($salesByCategory as $category) {
            $html .= '<tr>';
            $html .= '<td>' . htmlspecialchars($category['category']) . '</td>';
            $html .= '<td style="text-align: center;">' . htmlspecialchars($category['total_quantity']) . '</td>';
            $html .= '<td style="text-align: right;">₱' . number_format($category['total_sales'], 2) . '</td>';
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';

        $pdf->writeHTML($html, true, false, true, false, '');

        $filename = 'business_sales_report_' . date('Y-m-d_h.iA') . '.pdf';

        $pdf->Output($filename, 'D');
        exit();

    } catch (Exception $e) {
        die("Error generating PDF file: " . $e->getMessage());
    }
}
?>
