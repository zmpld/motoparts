<?php

require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

session_start();
include 'config.php'; // Include your database connection settings

// Check if the user is logged in and has the correct role
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    die("Unauthorized access");
}

// Fetch summary data from the database

// Total sales
$totalSalesQuery = "SELECT SUM(total_price) AS total_sales FROM orders";
$totalSalesResult = $conn->query($totalSalesQuery);
$totalSales = $totalSalesResult->fetch_assoc()['total_sales'] ?? 0;

// Total number of orders
$totalOrdersQuery = "SELECT COUNT(*) AS total_orders FROM orders";
$totalOrdersResult = $conn->query($totalOrdersQuery);
$totalOrders = $totalOrdersResult->fetch_assoc()['total_orders'] ?? 0;

// Sales by product
$salesByProductQuery = "SELECT tracking_number, product_name, SUM(quantity) AS total_quantity, SUM(total_price) AS total_sales FROM orders GROUP BY tracking_number, product_name";
$salesByProductResult = $conn->query($salesByProductQuery);
$salesByProduct = [];
while ($row = $salesByProductResult->fetch_assoc()) {
    $salesByProduct[] = $row;
}

// Sales by category (assuming a 'category' column in orders or join with products table)
$salesByCategoryQuery = "SELECT category, SUM(orders.quantity) AS total_quantity, SUM(total_price) AS total_sales FROM orders JOIN user_registration.inventory ON orders.product_name = user_registration.inventory.product_name GROUP BY category";
$salesByCategoryResult = $conn->query($salesByCategoryQuery);
$salesByCategory = [];
if ($salesByCategoryResult) {
    while ($row = $salesByCategoryResult->fetch_assoc()) {
        $salesByCategory[] = $row;
    }
}

// Close connection
$conn->close();

// Handle export requests
if (isset($_GET['export'])) {
    $format = strtolower($_GET['export']);
    if (!in_array($format, ['pdf', 'excel'])) {
        die("Invalid export format.");
    }

    

    if ($format === 'excel') {
        // Use statements must be at the top of the file, so use fully qualified names here
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle("Business Report");

        // Set summary data
        $sheet->setCellValue('A1', 'Total Sales');
        $sheet->setCellValue('B1', $totalSales);
        $sheet->setCellValue('A2', 'Total Orders');
        $sheet->setCellValue('B2', $totalOrders);

        // Sales by product header
        $sheet->setCellValue('A4', 'Sales by Product');
        $sheet->fromArray(['Tracking Number', 'Product Name', 'Total Quantity', 'Total Sales'], NULL, 'A5');

        // Sales by product data
        $rowIndex = 6;
        foreach ($salesByProduct as $product) {
            $sheet->setCellValue("A{$rowIndex}", $product['tracking_number']);
            $sheet->setCellValue("B{$rowIndex}", $product['product_name']);
            $sheet->setCellValue("C{$rowIndex}", $product['total_quantity']);
            $sheet->setCellValue("D{$rowIndex}", $product['total_sales']);
            $rowIndex++;
        }

        // Sales by category header
        $rowIndex += 2;
        $sheet->setCellValue("A{$rowIndex}", 'Sales by Category');
        $sheet->fromArray(['Category', 'Total Quantity', 'Total Sales'], NULL, "A" . ($rowIndex + 1));

        // Sales by category data
        $rowIndex += 2;
        foreach ($salesByCategory as $category) {
            $sheet->setCellValue("A{$rowIndex}", $category['category']);
            $sheet->setCellValue("B{$rowIndex}", $category['total_quantity']);
            $sheet->setCellValue("C{$rowIndex}", $category['total_sales']);
            $rowIndex++;
        }

        // Set headers for download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="business_report.xlsx"');
        header('Cache-Control: max-age=0');

        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save('php://output');
        exit();
    } else {
        // PDF export using TCPDF
        $pdf = new \TCPDF();
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 12);

        $html = '<h2>Business Report</h2>';
        $html .= '<h3>Summary</h3>';
        $html .= '<p>Total Sales: ' . number_format($totalSales, 2) . '</p>';
        $html .= '<p>Total Orders: ' . $totalOrders . '</p>';

$html .= '<h3>Sales by Product</h3>';
$html .= '<table border="1" cellpadding="4"><tr><th>Tracking Number</th><th>Product Name</th><th>Total Quantity</th><th>Total Sales</th></tr>';
foreach ($salesByProduct as $product) {
    $html .= '<tr>';
    $html .= '<td>' . htmlspecialchars($product['tracking_number']) . '</td>';
    $html .= '<td>' . htmlspecialchars($product['product_name']) . '</td>';
    $html .= '<td>' . $product['total_quantity'] . '</td>';
    $html .= '<td>' . number_format($product['total_sales'], 2) . '</td>';
    $html .= '</tr>';
}
$html .= '</table>';

        $html .= '<h3>Sales by Category</h3>';
        $html .= '<table border="1" cellpadding="4"><tr><th>Category</th><th>Total Quantity</th><th>Total Sales</th></tr>';
        foreach ($salesByCategory as $category) {
            $html .= '<tr>';
            $html .= '<td>' . htmlspecialchars($category['category']) . '</td>';
            $html .= '<td>' . $category['total_quantity'] . '</td>';
            $html .= '<td>' . number_format($category['total_sales'], 2) . '</td>';
            $html .= '</tr>';
        }
        $html .= '</table>';

        $pdf->writeHTML($html);
        $pdf->Output('business_report.pdf', 'D');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotoParts Manager - Admin</title>
    <link rel="stylesheet" href="adminstyle.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="adminstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <script src="script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
</head>

<body>
<!----- NAVBAR ---------- NAVBAR ---------- NAVBAR ----->
<nav class="navbar">
    <div class="navdiv">
        <div class="logo">
            <img src="assets/logo.jpg" alt="MotoParts Manager">
        </div>
        <ul style="padding-top: 20px; padding-right: 20px;">
            <li><a class="hac active" href="#">Home</a></li>
            <li><a class="hac" href="about_admin.html">About</a></li>
            <li class="dropdown">
                <a class="hac" href="#" id="contactLink">Contact</a>
                <ul class="dropdown_menu" id="contactDropdown">
                    <li><p>(+63) 9298642708</p></li>
                    <li><p>mtmotoparts@gmail.com</p></li>
                </ul>
            </li>
            <li><a class="hac active" href="logout.php" style="display: inline-block; padding: 12px 40px; min-width: 125%; text-align: center;"><i class='bx bx-log-out'></i> Log Out</a></li>
        </ul>
    </div>
</nav>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const contactLink = document.getElementById("contactLink");
    const contactDropdown = document.getElementById("contactDropdown");

    if (contactLink && contactDropdown) {
        contactLink.addEventListener("click", function (event) {
            event.preventDefault();
            contactDropdown.classList.toggle("open");
        });

        // Close dropdown when clicking outside
        document.addEventListener("click", function (event) {
            if (!contactLink.contains(event.target) && !contactDropdown.contains(event.target)) {
                contactDropdown.classList.remove("open");
            }
        });
    } else {
        console.error("Contact elements not found in the DOM.");
    }
});
</script>

<!----- SUBBAR ---------- SUBBAR ---------- SUBBAR ----->
<nav class="subBar">
    <div class="subdiv">
        <ul>
            <li><a class="hac" href="product_sales.php">Product Sales Analytics</a></li>
            <li><a class="hac" href="inventory_status.php">Inventory Status</a></li>
            <li><a class="hac" href="users.php">Users</a></li>
            <li><a class="hac" href="orders.php">Orders</a></li>
            <li><a class="hac" href="business_report.php">Business Report</a></li>
            <!-- <li><a class="hac" href="archive_logs.php">Archive Logs</a></li> -->
        </ul>
    </div>
</nav>

    <a href="adminpage.php" style="display:inline-block; margin: 10px 0; padding: 8px 15px; background-color: #6c757d; color: white; text-decoration: none; border-radius: 4px;">Back to Admin Page</a>
    <div style="text-align: center; margin-bottom: 20px; margin-top: 10px;">
        <a href="business_export.php?format=pdf" class="btn-export" target="_blank" style="margin-right: 10px; background-color: #d9534f; color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none;">
            Export Sales PDF
        </a>
        <a href="business_export.php?format=excel" class="btn-export" target="_blank" style="margin-left: 10px; background-color: #5cb85c; color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none;">
            Export Sales Excel
        </a>
    </div>
    <h1 style="margin: 10px">Business Report Preview</h1>
    <h2 style="margin: 10px">Summary</h2>
    <p style="margin: 10px">Total Sales: <?php echo number_format($totalSales, 2); ?></p>
    <p style="margin: 10px">Total Orders: <?php echo $totalOrders; ?></p>

    <h2 style="margin: 10px">Sales by Product</h2>
    <table  style="margin: 10px" border="1" cellpadding="4">
        <tr>
            <th>Tracking Number</th>
            <th>Product Name</th>
            <th>Total Quantity</th>
            <th>Total Sales</th>
        </tr>
        <?php foreach ($salesByProduct as $product): ?>
        <tr>
            <td><?php echo htmlspecialchars($product['tracking_number']); ?></td>
            <td><?php echo htmlspecialchars($product['product_name']); ?></td>
            <td><?php echo $product['total_quantity']; ?></td>
            <td><?php echo number_format($product['total_sales'], 2); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h2 style="margin: 10px">Sales by Category</h2>
    <table style="margin: 10px" border="1" cellpadding="4">
        <tr>
            <th>Category</th>
            <th>Total Quantity</th>
            <th>Total Sales</th>
        </tr>
        <?php foreach ($salesByCategory as $category): ?>
        <tr>
            <td><?php echo htmlspecialchars($category['category']); ?></td>
            <td><?php echo $category['total_quantity']; ?></td>
            <td><?php echo number_format($category['total_sales'], 2); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

</body>
</html>
