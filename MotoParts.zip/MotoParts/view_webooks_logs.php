<?php
include 'config.php';
$result = $conn->query("SELECT * FROM webhook_logs ORDER BY received_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>PayRex Webhook Activity</title>
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 10px; }
        th { background-color: #f2f2f2; }
        pre { white-space: pre-wrap; word-wrap: break-word; }
    </style>
</head>
<body>
    <h1>PayRex Webhook Activity</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Event</th>
            <th>Status</th>
            <th>Tracking #</th>
            <th>Payload</th>
            <th>Received</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['event_type']) ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td><?= htmlspecialchars($row['tracking_number']) ?></td>
            <td><pre><?= htmlspecialchars($row['raw_payload']) ?></pre></td>
            <td><?= $row['received_at'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>