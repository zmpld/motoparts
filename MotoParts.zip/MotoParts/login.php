<?php
session_start();

$host = 'localhost';
$db_username = 'root';
$db_password = '';
$database = 'user_registration';

// Connect to MySQL
$conn = mysqli_connect($host, $db_username, $db_password, $database);
if (!$conn) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login'])) {
        $username = trim($_POST['username']); // This is either username or email
        $password = trim($_POST['password']);

        // Check if user exists and get their role - check against both username and email
        $query = "SELECT email, password, role FROM users WHERE email = ? OR username = ?";
        $stmt = mysqli_prepare($conn, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ss", $username, $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            mysqli_stmt_close($stmt);
            
            if ($result && $row = mysqli_fetch_assoc($result)) {
                if (password_verify($password, $row['password'])) {
                    // Store user info in session
                    $_SESSION['email'] = $row['email']; // Store email in session
                    $_SESSION['username'] = $username;
                    $_SESSION['role'] = $row['role'];
                    
                    // Debug information
                    error_log("Login successful. Role: " . $row['role']);
                    
                    // Redirect based on role from database
                    switch($row['role']) {
                        case 'admin':
                            header('Location: adminpage.php');
                            exit();
                        case 'retailer':
                            header('Location: retailerpage.php');
                            exit();
                        default:
                            header('Location: customerpage.php');
                            exit();
                    }
                } else {
                    echo "<p style='color: white; background: black;'>Invalid username or password.</p>";
                }
            } else {
                echo "<p style='color: white; background: black;'>Invalid username or password.</p>";
            }
        } else {
            echo "<p style='color: white; background: black;'>SQL Error: " . mysqli_error($conn) . "</p>";
        }
    } elseif (isset($_POST['register'])) {
        $username = trim($_POST['username']);
        $firstname = trim($_POST['firstname']);
        $lastname = trim($_POST['lastname']);
        $password = trim($_POST['password']);
        $email = trim($_POST['email']);
        $address = trim($_POST['address']);
        
        // Determine role based on email domain
        $role = 'customer'; // Default role
        if (strpos($email, '@admin.com') !== false) {
            $role = 'admin';
        } elseif (strpos($email, '@retailer.com') !== false) {
            $role = 'retailer';
        }

        // Create XML for SOAP
        $xml = new SimpleXMLElement('<user></user>');
        $xml->addChild('username', $username);
        $xml->addChild('firstname', $firstname);
        $xml->addChild('lastname', $lastname);
        $xml->addChild('password', $password);
        $xml->addChild('email', $email);
        $xml->addChild('address', $address);
        $xml->addChild('role', $role);

        try {
            $client = new SoapClient('http://127.0.0.1/MotoParts/user_registration.wsdl');
            $response = $client->registerUser($xml->asXML());
            
            if (strpos($response, 'successful') !== false || strpos($response, 'already registered') !== false) {
                $_SESSION['registration_success'] = "Registration successful! Please log in.";
                header('Location: login.php');
                exit();
            } else {
                echo "<h2>Registration Error: $response</h2>";
            }
        } catch (Exception $e) {
            echo "<h2>SOAP Error: " . $e->getMessage() . "</h2>";
        }
    }
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotoParts - Log in</title>
    <link rel="stylesheet" href="loginstyle.css">
    <script src="script.js"></script>
    <link href="https://fonts.cdnfonts.com/css/arcade-classic" rel="stylesheet">
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer">
</head>
<body>
    <div class="container1">
        <a class="navbar1" href="index.php" style="color: black;">
                Browse products &#8594;
        </a>
    </div>

<div class="wrapper">
    <div class="form-box">
            <!------------------- login form -------------------------->
            <div class="login-container" id="login">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                    <div class="input-box">
                        <input type="text" name="username" class="input-field" placeholder="Username or Email">
                        <i class="bx bx-user"></i>
                    </div>
                    <div class="input-box">
                        <input type="password" name="password" class="input-field" placeholder="Password">
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="submit" name="login" class="submit" value="Log In">
                    </div>
                </form>
                <div class="top">
                    <span><span style="color:white">Don't have an account? </span><a href="#" onclick="register()">Register now!</a></span>
                </div>
                <div class="two-col">
                    <div class="one">
                        <input type="checkbox" id="login-check" style="margin-top: -8px;">
                        <label for="login-check"> Remember Me</label>
                        </div>
                        <div class="two">
                            <label><a href="#">Forgot password?</a></label>
                        </div>
                    </div>
                </div>
            <!------------------- registration form -------------------------->
            <div class="register-container" id="register">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <div class="input-box">
                        <input type="username" name="username" class="input-field" placeholder="Username">
                        <i class="bx bx-user"></i>
                    </div>
                    <div class="two-forms">
                        <div class="input-box">
                            <input type="text" name="firstname" class="input-field" placeholder="Firstname">
                            <i class="bx bx-user"></i>
                        </div>
                        <div class="input-box">
                            <input type="text" name="lastname" class="input-field" placeholder="Lastname">
                            <i class="bx bx-user"></i>
                        </div>
                    </div>
                    <div class="input-box">
                        <input type="email" name="email" class="input-field" placeholder="Email">
                        <i class="bx bx-envelope"></i>
                    </div>
                    <div class="input-box">
                        <input type="password" name="password" class="input-field" placeholder="Password">
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" id="address" name="address" class="input-field" placeholder="Address">
                        <i class="bx bx-map"></i>
                    </div>
                    <div class="input-box">
                        <input type="submit" name="register" class="submit" value="Register">
                    </div>
                    <div class="top">
                        <span style="margin-top: 40px;"><span style="color:white">Have an account?</span> <a href="#" onclick="login()">Log In</a></span>
                    </div>
                    <div class="two-col">
                        <div class="one">
                            <input type="checkbox" id="register-check" style="margin-top: -8px;">
                            <label for="register-check"> Remember Me</label>
                        </div>
                        <div class="two">
                            <label><a href="#">Terms & conditions</a></label>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </>

    <script>
        var a = document.getElementById("loginBtn");
        var b = document.getElementById("registerBtn");
        var x = document.getElementById("login");
        var y = document.getElementById("register");

        function login() {
            x.style.left = "4px";
            y.style.right = "-520px";
            a.className += " white-btn";
            b.className = "btn";
            x.style.opacity = 1;
            y.style.opacity = 0;
        }

        function register() {
            x.style.left = "-510px";
            y.style.right = "5px";
            a.className = "btn";
            b.className += " white-btn";
            x.style.opacity = 0;
            y.style.opacity = 1;
        }
    </script>

</body>
</html>


