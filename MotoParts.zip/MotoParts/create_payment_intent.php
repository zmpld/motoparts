<?php
// Create a CheckoutSession
    $checkoutSession = $payrex->checkoutSessions->create([
        'currency' => 'PHP',
        // URL where your customer will be redirected after a successful payment.
        'success_url' => 'customerpage.php',
        // URL where your customer will be redirected if they decide to not proceed with a payment
        'cancel_url' => 'customerpage.php',
        'payment_methods' => ['gcash', 'card', 'maya', 'qrph'],
        'line_items' => [
            [
                'name' => 'Item 1',
                // Amount is in cents. The sample below is 100.00.
                'amount' => 10000,
                'quantity' => 1,
                // optional
                // 'image' => 'uploads/engines2.jpg'
            ]
        ]
    ]);

    $output = [
        'url' => $checkoutSession->url,
    ];

    echo json_encode($output);
// } catch (Exception $e) {
//     http_response_code(500);
//     echo json_encode(['error' => 'Failed to create checkout session', 'message' => $e->getMessage()]);
// }

try {
    // Create a CheckoutSession
    $checkoutSession = $payrex->checkoutSessions->create([
        'currency' => 'PHP',
        // URL where your customer will be redirected after a successful payment.
        'success_url' => 'http://9b9477c1a6b9.ngrok-free.app/MotoParts/customerpage.php',
        // URL where your customer will be redirected if they decide to not proceed with a payment
        'cancel_url' => 'http://9b9477c1a6b9.ngrok-free.app/MotoParts/customerpage.php',
        'payment_methods' => ['gcash', 'card', 'maya', 'qrph'],
        'line_items' => [
            [
                'name' => 'Item 1',
                // Amount is in cents. The sample below is 100.00.
                'amount' => 10000,
                'quantity' => 1,
                // optional
                // 'image' => 'uploads/engines2.jpg'
            ]
        ]
    ]);

    $output = [
        'url' => $checkoutSession->url,
    ];

    echo json_encode($output);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to create checkout session', 'message' => $e->getMessage()]);
}
?>