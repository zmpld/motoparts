<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;

session_start();
include 'config.php';

if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'customer') {
    die("Unauthorized access");
}

$customer_email = $_SESSION['email'];

$stmt = $conn->prepare("SELECT order_id, customer_email, product_name, quantity, total_price, order_date, order_status, payment_status, shipping_date, tracking_number, payment_method, Order_Address, created_at FROM orders WHERE customer_email = ?");
$stmt->bind_param("s", $customer_email);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}
$stmt->close();
$conn->close();

// Check if there are orders to export
if (empty($orders)) {
    die("No orders found for export.");
}

$format = $_GET['format'] ?? 'pdf';

if ($format === 'excel') {
    try {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle("Order Summary");

        $logoPath = 'assets/logo.jpg';
        if (file_exists($logoPath)) {
            $drawing = new Drawing();
            $drawing->setName('Company Logo');
            $drawing->setDescription('Company Logo');
            $drawing->setPath($logoPath);
            $drawing->setHeight(50);
            $drawing->setCoordinates('B1'); // Position logo on the right side
            $drawing->setOffsetX(10);
            $drawing->setOffsetY(5);
            $drawing->setWorksheet($sheet);
        }

        // Add header text
        $sheet->setCellValue('A1', 'Order Summary Report');
        $sheet->setCellValue('A1', 'Moto Parts Manager');
        $sheet->mergeCells('A1:I1');
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
        $sheet->getStyle('A1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT);

        // Add customer info
        $sheet->setCellValue('A2', 'Customer: ' . $customer_email);
        date_default_timezone_set('Asia/Manila');
        $sheet->setCellValue('A3', 'Generated: ' . date('Y-m-d h:i:s A'));


        // Updated headers to match your database
        $headers = [
            'Order ID', 'Product Name', 'Quantity', 'Total Price', 'Order Date', 
            'Order Status', 'Payment Status', 'Payment Method', 'Shipping Date', 
            'Tracking Number', 'Address', 'Created At'
        ];
        $sheet->fromArray($headers, null, 'A5');

        // Style the header row
        $headerStyle = [
            'font' => ['bold' => true, 'color' => ['rgb' => '000000']],
            'fill' => [
                'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E2E8F0']
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    'color' => ['rgb' => '000000']
                ]
            ]
        ];
        $sheet->getStyle('A5:L5')->applyFromArray($headerStyle);

        // Add data
        $rowIndex = 6;
        foreach ($orders as $order) {
            $sheet->setCellValue("A{$rowIndex}", $order['order_id']);
            $sheet->setCellValue("B{$rowIndex}", $order['product_name']);
            $sheet->setCellValue("C{$rowIndex}", $order['quantity']);
            $sheet->setCellValue("D{$rowIndex}", 'PHP' . number_format($order['total_price'], 2));
            $sheet->setCellValue("E{$rowIndex}", $order['order_date']);
            $sheet->setCellValue("F{$rowIndex}", $order['order_status']);
            $sheet->setCellValue("G{$rowIndex}", $order['payment_status']);
            $sheet->setCellValue("H{$rowIndex}", $order['payment_method']);
            $sheet->setCellValue("I{$rowIndex}", $order['shipping_date'] ?? 'N/A');
            $sheet->setCellValue("J{$rowIndex}", $order['tracking_number'] ?? 'N/A');
            $sheet->setCellValue("K{$rowIndex}", $order['Order_Address']);
            $sheet->setCellValue("L{$rowIndex}", $order['created_at']);
            
            // Add borders to data rows
            $sheet->getStyle("A{$rowIndex}:L{$rowIndex}")->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
            
            $rowIndex++;
        }

        // Add total row
        $totalAmount = array_sum(array_column($orders, 'total_price'));
        $sheet->setCellValue("A{$rowIndex}", 'Total Orders: ' . count($orders));
        $sheet->mergeCells("A{$rowIndex}:C{$rowIndex}");
        $sheet->setCellValue("D{$rowIndex}", 'PHP' . number_format($totalAmount, 2));
        $sheet->getStyle("A{$rowIndex}:L{$rowIndex}")->getFont()->setBold(true);
        $sheet->getStyle("A{$rowIndex}:L{$rowIndex}")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB('F9F9F9');

        // Auto-size columns
        foreach (range('A', 'L') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        // Set up header and footer
        $sheet->getHeaderFooter()->setOddHeader('&L&B&16Order Summary Report&R&G'); // &G for logo placeholder
        $sheet->getHeaderFooter()->setOddFooter('&L&D &T&RPage &P of &N'); // Date/Time left, Page right

        // Clear any previous output
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Set headers for Excel download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="order_summary_' . date('Y-m-d_h.ia') . '.xlsx"');
        header('Cache-Control: max-age=0');
        header('Cache-Control: max-age=1');
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
        header('Cache-Control: cache, must-revalidate');
        header('Pragma: public');

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit();

    } catch (Exception $e) {
        die("Error generating Excel file: " . $e->getMessage());
    }

} else {
    // PDF export using TCPDF
    try {
        // Clear any previous output
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Extend TCPDF to override Header and Footer
                class CustomPDF extends TCPDF {
    public function Header() {
        $logoPath = 'assets/logo.jpg';

        // Add logo on the left
        if (file_exists($logoPath)) {
            $this->Image($logoPath, 10, 10, 30);
        }

        // Company Name and Subtitle to the left of the header
        $this->SetFont('helvetica', 'B', 16);
        $this->SetXY(45, 10);
        $this->Cell(100, 10, 'Moto Parts Manager', 0, 1, 'L');

        $this->SetFont('helvetica', '', 10);
        $this->SetX(45);
        $this->Cell(100, 6, 'Order Summary Report', 0, 1, 'L');

        // Customer email on the right
        $this->SetFont('helvetica', '', 9);
        $this->SetXY(200, 12); // adjust X and Y as needed for positioning
        $this->Cell(0, 6, 'Customer: ' . $_SESSION['email'], 0, 1, 'R');

        // Add spacing before content
        $this->Ln(10);
    }

    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', '', 8);
        date_default_timezone_set('Asia/Manila');
        $this->Cell(0, 10, 'Generated: ' . date('Y-m-d h:i:s A'), 0, 0, 'L');
        $this->Cell(0, 10, 'Page ' . $this->getAliasNumPage() . ' of ' . $this->getAliasNbPages(), 0, 0, 'R');
    }
}



        $pdf = new CustomPDF('L', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false); // 'L' for landscape

        // Set document information
        $pdf->SetCreator('Moto Parts Management System');
        $pdf->SetAuthor('Your Company');
        $pdf->SetTitle('Order Invoice');
        $pdf->SetSubject('Customer Orders');

        // Set margins
        $pdf->SetMargins(10, 25, 10); // Increased top margin for custom header
        $pdf->SetHeaderMargin(0);
        $pdf->SetFooterMargin(15);

        // Set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, 15);

        // Add a page
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 8);

        // Build HTML content for the table
        $html = '<table border="1" cellpadding="4" cellspacing="0" style="width: 100%; font-size: 7px;">';
        $html .= '<thead>';
        $html .= '<tr style="background-color: #E2E8F0; font-weight: bold; color: #000000;">';
        $html .= '<th >Order ID</th>';
        $html .= '<th >Product</th>';
        $html .= '<th >Qty</th>';
        $html .= '<th >Price</th>';
        $html .= '<th >Order Date</th>';
        $html .= '<th >Status</th>';
        $html .= '<th >Payment</th>';
        $html .= '<th >Method</th>';
        $html .= '<th >Shipping</th>';
        $html .= '<th >Address</th>';
        $html .= '</tr>';
        $html .= '</thead>';
        $html .= '<tbody>';

        $totalAmount = 0;
        foreach ($orders as $order) {
            $html .= '<tr>';
            $html .= '<td>' . htmlspecialchars($order['order_id']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['product_name']) . '</td>';
            $html .= '<td style="text-align: center;">' . htmlspecialchars($order['quantity']) . '</td>';
            $html .= '<td style="text-align: right;">PHP ' . number_format($order['total_price'], 2) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['order_date']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['order_status']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['payment_status']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['payment_method']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['shipping_date'] ?? 'N/A') . '</td>';
            $html .= '<td>' . htmlspecialchars(substr($order['Order_Address'], 0, 30)) . (strlen($order['Order_Address']) > 30 ? '...' : '') . '</td>';
            $html .= '</tr>';
            $totalAmount += $order['total_price'];
        }

        $html .= '</tbody>';
        $html .= '<tfoot>';
        $html .= '<tr style="background-color: #F9F9F9; font-weight: bold;">';
        $html .= '<td colspan="3">Total Orders: ' . count($orders) . '</td>';
        $html .= '<td style="text-align: right;">PHP' . number_format($totalAmount, 2) . '</td>';
        $html .= '<td colspan="6"></td>';
        $html .= '</tr>';
        $html .= '</tfoot>';
        $html .= '</table>';

        $pdf->writeHTML($html, true, false, true, false, '');

        // Output PDF
        date_default_timezone_set('Asia/Manila'); // Set timezone to Philippines

        $hour = date('H');
        $minute = date('i');
        $ampm = date('a');
        $timeNow = date('h.i') . $ampm;

        // Determine the time range based on current hour
        if ($hour < 13) {
            $timeRange = '12am-11.59am';
        } else {
            $timeRange = '1pm-11.59pm';
        }

        // Final output filename
        $filename = 'order_invoice_' . date('Y-m-d') . '_' . $timeNow . '.pdf';

        // Output the PDF
        $pdf->Output($filename, 'D');
        exit();


    } catch (Exception $e) {
        die("Error generating PDF file: " . $e->getMessage());
    }
}
?>