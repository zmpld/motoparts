<?php
session_start();
include 'config.php';

if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];

// Fetch all orders by this customer, grouped by order_id
$stmt = $conn->prepare("
    SELECT order_id, product_name, quantity, total_price, order_date, order_status, 
           payment_status, tracking_number, payment_method
    FROM orders
    WHERE customer_email = ?
    ORDER BY order_date ASC
");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Group orders by order_id
$orders = [];
while ($row = $result->fetch_assoc()) {
    $id = $row['order_id'];
    if (!isset($orders[$id])) {
        $orders[$id] = [
            'order_date' => $row['order_date'],
            'order_status' => $row['order_status'],
            'payment_status' => $row['payment_status'],
            'tracking_number' => $row['tracking_number'],
            'payment_method' => $row['payment_method'],
            'items' => [],
            'total_price' => 0,
        ];
    }
    $orders[$id]['items'][] = [
        'product_name' => $row['product_name'],
        'quantity' => $row['quantity'],
        'price' => $row['total_price'],
    ];
    $orders[$id]['total_price'] += $row['total_price'];
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History – MotoParts Manager</title>
    <link rel="stylesheet" href="i.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            min-height: 100vh;
            padding: 20px;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .header {
            background: #2c3e50;
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
        }

        .header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .header p {
            opacity: 0.9;
            font-size: 1.1rem;
        }

        .btn-export {
            display: inline-block;
            background-color: #1abc9c;
            color: white;
            padding: 10px 18px;
            margin-left: 10px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .btn-export:hover {
            background-color: #16a085;
            color: white;
        }


        .btn-back {
            position: absolute;
            left: 30px;
            top: 50%;
            transform: translateY(-50%);
            background: #e67e22;
            border: none;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }

        .btn-back:hover {
            background: #d35400;
            transform: translateY(-50%) translateX(-5px);
            color: white;
        }

        .content {
            padding: 40px;
        }

        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: #6b7280;
        }

        .empty-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 30px;
            background: #e67e22;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
        }

        .empty-state h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #374151;
        }

        .orders-container {
            display: grid;
            gap: 25px;
        }

        .order-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }

        .order-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .order-header {
            background: #ecf0f1;
            padding: 25px;
            border-bottom: 1px solid #bdc3c7;
        }

        .order-id {
            font-size: 1.4rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .order-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .meta-label {
            font-size: 0.85rem;
            color: #6b7280;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .meta-value {
            font-weight: 600;
            color: #2c3e50;
            font-size: 1rem;
        }

        .status-badge {
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-block;
        }

        .status-pending {
            background: #f39c12;
            color: white;
        }

        .status-unshipped {
            background: #3498db;
            color: white;
        }

        .status-shipped {
            background: #27ae60;
            color: white;
        }

        .status-delivered {
            background: #2ecc71;
            color: white;
        }

        .status-cancelled {
            background: #e74c3c;
            color: white;
        }

        .payment-unpaid {
            background: #3498db;
            color: white;
        }

        .payment-paid {
            background: #27ae60;
            color: white;
        }

        .payment-pending {
            background: #f39c12;
            color: white;
        }

        .payment-refunded {
            background: #e74c3c;
            color: white;
        }

        .order-body {
            padding: 25px;
        }

        .items-section h4 {
            font-size: 1.2rem;
            color: #2c3e50;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .item-list {
            list-style: none;
            padding: 0;
            margin-bottom: 20px;
        }

        .item {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.2s ease;
        }

        .item:hover {
            background: #ecf0f1;
            border-color: #bdc3c7;
        }

        .item-info {
            flex: 1;
        }

        .item-name {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .item-details {
            color: #7f8c8d;
            font-size: 0.9rem;
        }

        .item-price {
            font-weight: 700;
            color: #e67e22;
            font-size: 1.1rem;
        }

        .order-total {
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 8px;
            margin-top: 20px;
        }

        .order-total .total-label {
            font-size: 1rem;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .order-total .total-amount {
            font-size: 1.8rem;
            font-weight: 700;
        }

        .tracking-info {
            background: #ecf0f1;
            border: 1px solid #bdc3c7;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .tracking-info i {
            color: #e67e22;
            font-size: 1.2rem;
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
            }

            .header {
                padding: 20px;
            }

            .header h1 {
                font-size: 2rem;
            }

            .btn-back {
                position: static;
                transform: none;
                margin-bottom: 20px;
            }

            .content {
                padding: 20px;
            }

            .order-meta {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .item {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }

            .item-price {
                align-self: flex-end;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <a href="customerpage.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back
            </a>
            <h1>Your Order History</h1>
            <p>Track and manage all your orders</p>
        </div>

        <div class="content">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="export_order.php?format=pdf" class="btn-export" target="_blank">
                    <i class="fas fa-file-pdf"></i> Download PDF
                </a>
                <a href="export_order.php?format=excel" class="btn-export" target="_blank">
                    <i class="fas fa-file-excel"></i> Download Excel
                </a>
            </div>
            <?php if (empty($orders)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-shopping-bag"></i>
                    </div>
                    <h3>No Orders Yet</h3>
                    <p>You haven't placed any orders yet. Start shopping to see your order history here!</p>
                </div>
            <?php else: ?>
                <div class="orders-container">
                    <?php foreach ($orders as $order_id => $order): ?>
                        <div class="order-card">
                            <div class="order-header">
                                <div class="order-id">
                                    <i class="fas fa-receipt"></i>
                                    Order #<?= htmlspecialchars($order_id); ?>
                                </div>
                                
                                <div class="order-meta">
                                    <div class="meta-item">
                                        <span class="meta-label">Order Date</span>
                                        <span class="meta-value">
                                            <i class="fas fa-calendar-alt"></i>
                                            <?= date('M d, Y', strtotime($order['order_date'])); ?>
                                        </span>
                                    </div>
                                    
                                    <div class="meta-item">
                                        <span class="meta-label">Order Status</span>
                                        <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $order['order_status'])); ?>">
                                            <?= htmlspecialchars($order['order_status']); ?>
                                        </span>
                                    </div>
                                    
                                    <div class="meta-item">
                                        <span class="meta-label">Payment Status</span>
                                        <span class="status-badge payment-<?= strtolower(str_replace(' ', '-', $order['payment_status'])); ?>">
                                            <?= htmlspecialchars($order['payment_status']); ?>
                                        </span>
                                    </div>
                                    
                                    <div class="meta-item">
                                        <span class="meta-label">Payment Method</span>
                                        <span class="meta-value">
                                            <i class="fas fa-credit-card"></i>
                                            <?= htmlspecialchars($order['payment_method']); ?>
                                        </span>
                                    </div>
                                </div>

                                <?php if (!empty($order['tracking_number']) && $order['tracking_number'] !== 'N/A'): ?>
                                    <div class="tracking-info">
                                        <i class="fas fa-truck"></i>
                                        <div>
                                            <strong>Tracking Number:</strong> <?= htmlspecialchars($order['tracking_number']); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="order-body">
                                <div class="items-section">
                                    <h4>
                                        <i class="fas fa-box"></i>
                                        Items Ordered (<?= count($order['items']); ?>)
                                    </h4>
                                    
                                    <ul class="item-list">
                                        <?php foreach ($order['items'] as $item): ?>
                                            <li class="item">
                                                <div class="item-info">
                                                    <div class="item-name"><?= htmlspecialchars($item['product_name']); ?></div>
                                                    <div class="item-details">Quantity: <?= $item['quantity']; ?></div>
                                                </div>
                                                <div class="item-price">₱<?= number_format($item['price'], 2); ?></div>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>

                                <div class="order-total">
                                    <div class="total-label">Total Amount</div>
                                    <div class="total-amount">₱<?= number_format($order['total_price'], 2); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Add smooth scrolling and enhanced interactions
        document.addEventListener('DOMContentLoaded', function() {
            // Add loading animation for order cards
            const orderCards = document.querySelectorAll('.order-card');
            orderCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.6s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });

            // Add click to copy tracking number
            const trackingInfos = document.querySelectorAll('.tracking-info');
            trackingInfos.forEach(info => {
                info.style.cursor = 'pointer';
                info.addEventListener('click', function() {
                    const trackingText = this.textContent.split(': ')[1];
                    if (navigator.clipboard) {
                        navigator.clipboard.writeText(trackingText).then(() => {
                            // Show temporary success message
                            const originalText = this.innerHTML;
                            this.innerHTML = '<i class="fas fa-check"></i> Tracking number copied!';
                            this.style.background = '#d5f4e6';
                            this.style.borderColor = '#27ae60';
                            setTimeout(() => {
                                this.innerHTML = originalText;
                                this.style.background = '#ecf0f1';
                                this.style.borderColor = '#bdc3c7';
                            }, 2000);
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>