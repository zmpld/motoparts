<?php
include_once("config.php");

function log_action($user_id, $retailer_id, $action_type, $description) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO action_logs (user_id, retailer_id, action_type, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $user_id_param, $retailer_id_param, $action_type_param, $description_param);

    $user_id_param = $user_id !== null ? $user_id : null;
    $retailer_id_param = $retailer_id !== null ? $retailer_id : null;
    $action_type_param = $action_type;
    $description_param = $description;

    $stmt->execute();
    $stmt->close();
}
?>
