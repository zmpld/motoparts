<?php
header("Content-Type: application/json");
include '../config.php';

$rawData = file_get_contents("php://input");
$payload = json_decode($rawData, true);

// Parse and validate
$event = $payload['event'] ?? null;
$data = $payload['data'] ?? [];
$tracking_number = $data['metadata']['tracking_number'] ?? null;

$status = match ($event) {
    'payment.success' => 'Paid',
    'payment.failed' => 'Failed',
    'payment.cancelled' => 'Cancelled',
    default => 'Unknown'
};

// Log the webhook activity
$stmt = $conn->prepare("INSERT INTO webhook_logs (event_type, tracking_number, status, raw_payload) VALUES (?, ?, ?, ?)");
$raw_json = json_encode($payload);
$stmt->bind_param("ssss", $event, $tracking_number, $status, $raw_json);
$stmt->execute();
$stmt->close();

// Update order status if valid
if ($tracking_number && $status !== 'Unknown') {
    $stmt = $conn->prepare("UPDATE orders SET payment_status = ? WHERE tracking_number = ?");
    $stmt->bind_param("ss", $status, $tracking_number);
    $stmt->execute();
    $stmt->close();
}

http_response_code(200);
echo json_encode(['message' => 'Webhook processed']);
?>