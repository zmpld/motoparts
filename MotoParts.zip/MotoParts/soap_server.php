<?php

$server = new SoapServer("user_registration.wsdl");

class UserRegistration {
    private $host = 'localhost';
    private $dbname = 'user_registration';
    private $username = 'root';
    private $password = '';

    private function connect() {
        try {
            $conn = new PDO("mysql:host={$this->host};dbname={$this->dbname}", $this->username, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch (PDOException $e) {
            error_log("Connection failed: " . $e->getMessage());
            return null;
        }
    }

    public function registerUser($xml) {
        $userData = simplexml_load_string($xml);
        if ($userData === false) {
            return "Invalid XML format.";
        }

        // Extract and sanitize inputs
        $username = trim((string)$userData->username);
        $firstname = trim((string)$userData->firstname);
        $lastname = trim((string)$userData->lastname);
        $password = trim((string)$userData->password);
        $email = trim((string)$userData->email);
        
        // Handle optional address field
        $address = isset($userData->address) ? trim((string)$userData->address) : '';
        
        // Handle optional role field
        $role = isset($userData->role) ? trim((string)$userData->role) : 'customer';

        // Validate inputs
        if (empty($username) || empty($firstname) || empty($lastname) || empty($password) || empty($email)) {
            return "Error: Required fields are missing.";
        }

        // Connect to DB
        $conn = $this->connect();
        if ($conn) {
            try {
                // Check if user already exists
                $stmt = $conn->prepare("SELECT email FROM users WHERE email = :email");
                $stmt->bindParam(':email', $email);
                $stmt->execute();

                if ($stmt->rowCount() > 0) {
                    // User already exists - check if it was just inserted by the main script
                    // Just return success since we know the user is in the database
                    return "User already registered. This is normal when registering through the web interface.";
                }

                // If we get here, we need to insert the user (SOAP-only registration)
                // Hash password
                $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

                // Insert new user with role
                $stmt = $conn->prepare("INSERT INTO users (username, first_name, last_name, email, password, address, role) 
                                        VALUES (:username, :firstname, :lastname, :email, :password, :address, :role)");
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':firstname', $firstname);
                $stmt->bindParam(':lastname', $lastname);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $hashedPassword);
                $stmt->bindParam(':address', $address);
                $stmt->bindParam(':role', $role);

                if ($stmt->execute()) {
                    return "Registration successful!";
                } else {
                    return "Error: Could not register user.";
                }
            } catch (PDOException $e) {
                error_log("Database error: " . $e->getMessage());
                return "Error: Could not register user.";
            }
        }
        return "Database connection error.";
    }
}

$server->setClass("UserRegistration");
$server->handle();
?>

