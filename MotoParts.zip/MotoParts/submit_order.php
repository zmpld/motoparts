<?php
session_start();
include 'config.php';
require_once 'vendor/autoload.php';

if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

$customer_email = $_SESSION['email'];

// Get customer address
$stmt = $conn->prepare("SELECT address, username FROM users WHERE email = ?");
$stmt->bind_param("s", $customer_email);
$stmt->execute();
$stmt->bind_result($address, $username);
$stmt->fetch();
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['payment_method'])) {
    $payment_method = trim($_POST['payment_method']);
    $order_date = date("Y-m-d H:i:s");
    $tracking_number = "TRK" . strtoupper(substr(uniqid(), -10));
    $from_modal = isset($_POST['from_modal']) && $_POST['from_modal'] === 'true';

    // === COLLECT LINE ITEMS FOR PAYREX ===
    $line_items = [];

    // Prepare insert for order(s)
    $insert_stmt = $conn->prepare("
        INSERT INTO orders (
            customer_email, product_name, quantity, total_price,
            order_date, tracking_number, payment_method, order_address
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    if (!$insert_stmt) {
        die("Prepare failed: " . $conn->error);
    }

    if ($from_modal) {
        // ===== Buy Now (Single Item) =====
        $inventory_id = intval($_POST['inventory_id']);
        $quantity = intval($_POST['quantity']);

        $stmt = $conn->prepare("SELECT product_name, unit_price FROM inventory WHERE inventory_id = ?");
        $stmt->bind_param("i", $inventory_id);
        $stmt->execute();
        $stmt->bind_result($product_name, $unit_price);
        $stmt->fetch();
        $stmt->close();

        $total_price = $unit_price * $quantity;

        $insert_stmt->bind_param(
            "ssidssss",
            $customer_email,
            $product_name,
            $quantity,
            $total_price,
            $order_date,
            $tracking_number,
            $payment_method,
            $address
        );
        $insert_stmt->execute();

        // Add to PayRex line items (only if not COD)
        if (strtolower($payment_method) !== 'cash on delivery' && strtolower($payment_method) !== 'cod') {
            $line_items[] = [
                'name' => $product_name,
                'amount' => intval($unit_price * 100), // in centavos
                'quantity' => $quantity,
                //'image' => 'https://your-website.com/images/default.jpg' // optional
            ];
        }

    } else {
        // ===== Cart-based Orders =====
        $stmt = $conn->prepare("
            SELECT c.inventory_id, c.quantity, i.product_name, i.unit_price 
            FROM cart c 
            JOIN inventory i ON c.inventory_id = i.inventory_id 
            WHERE c.email = ?
        ");
        $stmt->bind_param("s", $customer_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            echo "No items in cart.";
            exit();
        }

        while ($row = $result->fetch_assoc()) {
            $product_name = $row['product_name'];
            $quantity = (int)$row['quantity'];
            $unit_price = (float)$row['unit_price'];
            $total_price = $unit_price * $quantity;

            $insert_stmt->bind_param(
                "ssidssss",
                $customer_email,
                $product_name,
                $quantity,
                $total_price,
                $order_date,
                $tracking_number,
                $payment_method,
                $address
            );
            $insert_stmt->execute();

            // Add to PayRex line items (only if not COD)
            if (strtolower($payment_method) !== 'cash on delivery' && strtolower($payment_method) !== 'cod') {
                $line_items[] = [
                    'name' => $product_name,
                    'amount' => intval($unit_price * 100),
                    'quantity' => $quantity,
                    'image' => 'https://your-website.com/images/default.jpg'
                ];
            }
        }

        $stmt->close();

        // Clear cart after order (only if not from modal)
        $clear_stmt = $conn->prepare("DELETE FROM cart WHERE email = ?");
        $clear_stmt->bind_param("s", $customer_email);
        $clear_stmt->execute();
        $clear_stmt->close();
    }

    $insert_stmt->close();
    $conn->close();

    // ✅ === CHECK PAYMENT METHOD AND REDIRECT ACCORDINGLY ===
    if (strtolower($payment_method) === 'cash on delivery' || strtolower($payment_method) === 'cod') {
        // For Cash on Delivery, redirect to customer page with success message
        header("Location: customerpage.php?order_success=1&tracking_number=$tracking_number");
        exit();
    } else {
        // ✅ === CREATE PAYREX CHECKOUT SESSION FOR NON-COD PAYMENTS ===
        try {
            $payrexSecretApiKey = 'sk_test_H5HJPdpzWf4CLrVb24fePdcUSKCjV3Xv'; // Replace this
            $payrex = new \Payrex\PayrexClient($payrexSecretApiKey);

            $checkoutSession = $payrex->checkoutSessions->create([
                'currency' => 'PHP',
                'success_url' => "https://9b9477c1a6b9.ngrok-free.app/MotoParts/payrex_callback.php?status=success&tracking_number=$tracking_number",
                'cancel_url' => "https://9b9477c1a6b9.ngrok-free.app/MotoParts/payrex_callback.php?status=cancel&tracking_number=$tracking_number",
                'payment_methods' => ['gcash', 'card', 'maya', 'qrph'],
                'line_items' => $line_items
            ]);

            // Redirect to PayRex hosted checkout
            header("Location: " . $checkoutSession->url);
            exit();

        } catch (Exception $e) {
            echo "❌ Failed to initiate PayRex checkout: " . $e->getMessage();
            exit();
        }
    }

} else {
    echo "Invalid order submission. Payment method not received.";
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
}