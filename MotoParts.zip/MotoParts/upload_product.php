<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "user_registration");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $product_name = $_POST['product_name'];
    $product_desc = $_POST['product_desc'];
    $category = $_POST['category'];
    $quantity = (int)$_POST['quantity'];
    $unit_price = (float)$_POST['unit_price'];

    // Handle file upload
    if (isset($_FILES['upload']) && $_FILES['upload']['error'] == 0) {
        $upload_dir = 'uploads/';
        $file_name = basename($_FILES['upload']['name']);
        $file_path = $upload_dir . $file_name;

        if (move_uploaded_file($_FILES['upload']['tmp_name'], $file_path)) {
            // Insert into inventory table (without order_id)
            $sql = "INSERT INTO inventory (product_name, product_desc, category, quantity, unit_price, image_path) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssids",$product_name, $product_desc, $category, $quantity, $unit_price, $file_path);

            if ($stmt->execute()) {
                echo "";
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Error uploading the file.";
        }
    } else {
        echo "No file uploaded or error in the file upload.";
    }

    header('Refresh: 2; URL = retailerpage.php');
}

$conn->close();
?>





<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotoParts Manager</title>
    <link rel="stylesheet" href="loginstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
</head>
<body>
   <div style="min-height: 95vh;" class="wrapper">
      <div>
         <header style="font-size: 30px; margin-top: -110px; color: #f5f5f1;"><b>Product added successfully!</b></header>
   </div>
   </div>
</body>
</html>

