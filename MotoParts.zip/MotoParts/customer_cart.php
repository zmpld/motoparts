<?php
session_start();
include 'config.php'; 

if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

$customer_email = $_SESSION['email'];
$username = "Not Logged In";
$address = "Not Logged In";

// Get customer username and address in one query
$stmt = $conn->prepare("SELECT username, address FROM users WHERE email = ?");
$stmt->bind_param("s", $customer_email);
$stmt->execute();
$stmt->bind_result($db_username, $db_address);
if ($stmt->fetch()) {
    $username = $db_username;
    $address = $db_address;
}
$stmt->close();

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $cart_id = intval($_POST['cart_id'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 1);

    if ($action === 'remove_from_cart') {
        $stmt = $conn->prepare("DELETE FROM cart WHERE cart_id = ? AND email = ?");
        $stmt->bind_param("is", $cart_id, $customer_email);
        $stmt->execute();
        $stmt->close();
        echo json_encode(['status' => 'success', 'message' => 'Item removed from cart!']);
        exit();
    }

    if ($action === 'update_quantity') {
        if ($quantity > 0) {
            $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE cart_id = ? AND email = ?");
            $stmt->bind_param("iis", $quantity, $cart_id, $customer_email);
        } else {
            $stmt = $conn->prepare("DELETE FROM cart WHERE cart_id = ? AND email = ?");
            $stmt->bind_param("is", $cart_id, $customer_email);
        }
        $stmt->execute();
        $stmt->close();
        echo json_encode(['status' => 'success', 'message' => 'Cart updated!']);
        exit();
    }

    if ($action === 'clear_cart') {
        $stmt = $conn->prepare("DELETE FROM cart WHERE email = ?");
        $stmt->bind_param("s", $customer_email);
        $stmt->execute();
        $stmt->close();
        echo json_encode(['status' => 'success', 'message' => 'Cart cleared!']);
        exit();
    }
}

// Get cart items
$cart_items = [];
$total_amount = 0;
$total_items = 0;

$stmt = $conn->prepare("
    SELECT c.cart_id, c.inventory_id, c.quantity,
           i.product_name, i.product_desc, i.unit_price, i.image_path
    FROM cart c
    JOIN inventory i ON c.inventory_id = i.inventory_id
    WHERE c.email = ?
");
$stmt->bind_param("s", $customer_email);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $row['subtotal'] = $row['unit_price'] * $row['quantity'];
    $total_amount += $row['subtotal'];
    $total_items += $row['quantity'];
    $cart_items[] = $row;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart - MotoParts Manager</title>
    <link rel="stylesheet" href="i.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: white;
            min-height: 100vh;
            padding: 20px 0;
        }
        
        .cart-container {
            max-width: 1200px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .cart-header {
            background: linear-gradient(135deg, #4a5568 0%, #2d3748 100%);
            color: white;
            padding: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .cart-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(250, 147, 78, 0.1) 0%, transparent 70%);
            animation: pulse 4s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.1; }
            50% { transform: scale(1.1); opacity: 0.2; }
        }
        
        .cart-header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
            position: relative;
            z-index: 1;
        }
        
        .cart-header h1 i {
            color: #fa934e;
            font-size: 36px;
        }
        
        .customer-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 20px;
            position: relative;
            z-index: 1;
        }
        
        .customer-info p {
            background: rgba(255, 255, 255, 0.1);
            padding: 12px 18px;
            border-radius: 10px;
            border-left: 4px solid #fa934e;
            font-weight: 500;
        }
        
        .cart-content {
            padding: 30px;
        }
        
        .btn-back {
            background: linear-gradient(135deg, #fa934e 0%, #ff6b35 100%);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-weight: 600;
            margin-bottom: 25px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(250, 147, 78, 0.3);
        }
        
        .btn-back:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(250, 147, 78, 0.4);
        }
        
        .cart-item {
            display: grid;
            grid-template-columns: 120px 1fr auto;
            gap: 25px;
            margin-bottom: 25px;
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .cart-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, #fa934e 0%, #ff6b35 100%);
        }
        
        .cart-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }
        
        .cart-item img {
            width: 100%;
            height: 100px;
            object-fit: cover;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .cart-details h3 {
            font-size: 18px;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 8px;
        }
        
        .cart-details p {
            color: #718096;
            margin-bottom: 12px;
            font-size: 14px;
            line-height: 1.5;
        }
        
        .price-section {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .price-section input[type="number"] {
            width: 70px;
            padding: 8px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            text-align: center;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .price-section input[type="number"]:focus {
            outline: none;
            border-color: #fa934e;
            box-shadow: 0 0 0 3px rgba(250, 147, 78, 0.1);
        }
        
        .subtotal {
            font-weight: 700;
            color: #fa934e;
            font-size: 16px;
        }
        
        .cart-item-actions {
            display: flex;
            flex-direction: column;
            justify-content: center;
            gap: 10px;
        }
        
        .btn {
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 14px;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #e53e3e 0%, #c53030 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(229, 62, 62, 0.3);
        }
        
        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(229, 62, 62, 0.4);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #38a169 0%, #2f855a 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(56, 161, 105, 0.3);
        }
        
        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(56, 161, 105, 0.4);
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #718096 0%, #4a5568 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(113, 128, 150, 0.3);
        }
        
        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(113, 128, 150, 0.4);
        }
        
        .cart-actions {
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            padding: 30px;
            border-radius: 15px;
            margin-top: 30px;
            text-align: center;
        }
        
        .cart-actions h2 {
            font-size: 24px;
            color: #2d3748;
            margin-bottom: 25px;
            font-weight: 700;
        }
        
        .cart-actions .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .empty-cart {
            text-align: center;
            padding: 60px 30px;
            color: #718096;
        }
        
        .empty-cart i {
            font-size: 80px;
            color: #e2e8f0;
            margin-bottom: 20px;
        }
        
        .empty-cart h2 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #4a5568;
        }
        
        .empty-cart a {
            color: #fa934e;
            text-decoration: none;
            font-weight: 600;
        }
        
        .empty-cart a:hover {
            text-decoration: underline;
        }
        
        #message {
            display: none;
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 12px;
            font-weight: 500;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        #message.success {
            background: linear-gradient(135deg, #c6f6d5 0%, #9ae6b4 100%);
            color: #22543d;
            border: 1px solid #9ae6b4;
        }
        
        @media (max-width: 768px) {
            .customer-info {
                grid-template-columns: 1fr;
            }
            
            .cart-item {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .cart-actions .btn-group {
                flex-direction: column;
                align-items: center;
            }
            
            .cart-actions .btn-group .btn {
                width: 100%;
                max-width: 300px;
            }
        }
    </style>
</head>
<body>
    <div class="cart-container">
        <div class="cart-header">
            <h1><i class='bx bx-cart'></i> Your Shopping Cart</h1>
            <div class="customer-info">
                <p><strong>Customer:</strong> <?= htmlspecialchars($username); ?></p>
                <p><strong>Delivery Address:</strong> <?= htmlspecialchars($address); ?></p>
            </div>
        </div>
        
        <div class="cart-content">
            <a href="customerpage.php" class="btn-back">
                <i class='bx bx-arrow-back'></i> Continue Shopping
            </a>

            <div id="message" class="message success"></div>

            <?php if (empty($cart_items)): ?>
                <div class="empty-cart">
                    <i class='bx bx-cart-alt'></i>
                    <h2>Your cart is empty</h2>
                    <p>Looks like you haven't added any items to your cart yet.</p>
                    <br>
                    <a href="customerpage.php" class="btn btn-back" style="color: white;">Start Shopping</a>
                </div>
            <?php else: ?>
                <?php foreach ($cart_items as $item): ?>
                    <div class="cart-item">
                        <img src="<?= htmlspecialchars($item['image_path']); ?>" alt="<?= htmlspecialchars($item['product_name']); ?>">
                        <div class="cart-details">
                            <h3><?= htmlspecialchars($item['product_name']); ?></h3>
                            <p><?= htmlspecialchars($item['product_desc']); ?></p>
                            <div class="price-section">
                                <span>₱<?= number_format($item['unit_price'], 2); ?></span>
                                <span>×</span>
                                <input type="number" value="<?= $item['quantity']; ?>" min="1" onchange="updateQuantity(<?= $item['cart_id']; ?>, this.value)">
                                <span>=</span>
                                <span class="subtotal">₱<?= number_format($item['subtotal'], 2); ?></span>
                            </div>
                        </div>
                        <div class="cart-item-actions">
                            <button class="btn btn-danger" onclick="removeFromCart(<?= $item['cart_id']; ?>)">
                                <i class='bx bx-trash'></i> Remove
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="cart-actions">
                    <h2>Total (<?= $total_items; ?> items): ₱<?= number_format($total_amount, 2); ?></h2>
                    <div class="btn-group">
                        <button class="btn btn-secondary" onclick="clearCart()">
                            <i class='bx bx-trash-alt'></i> Clear Cart
                        </button>
                        <a href="checkout.php" class="btn btn-success">
                            <i class='bx bx-credit-card'></i> Proceed to Checkout
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function showMessage(msg) {
            const box = document.getElementById("message");
            box.textContent = msg;
            box.style.display = 'block';
            setTimeout(() => box.style.display = 'none', 3000);
        }

        function updateQuantity(cartId, quantity) {
            const formData = new FormData();
            formData.append("action", "update_quantity");
            formData.append("cart_id", cartId);
            formData.append("quantity", quantity);

            fetch("customer_cart.php", {
                method: "POST",
                body: formData
            }).then(res => res.json()).then(data => {
                showMessage(data.message);
                setTimeout(() => location.reload(), 500);
            });
        }

        function removeFromCart(cartId) {
            const formData = new FormData();
            formData.append("action", "remove_from_cart");
            formData.append("cart_id", cartId);

            fetch("customer_cart.php", {
                method: "POST",
                body: formData
            }).then(res => res.json()).then(data => {
                showMessage(data.message);
                setTimeout(() => location.reload(), 500);
            });
        }

        function clearCart() {
            if (!confirm("Are you sure you want to clear the cart?")) return;
            const formData = new FormData();
            formData.append("action", "clear_cart");

            fetch("customer_cart.php", {
                method: "POST",
                body: formData
            }).then(res => res.json()).then(data => {
                showMessage(data.message);
                setTimeout(() => location.reload(), 500);
            });
        }
    </script>
</body>
</html>

