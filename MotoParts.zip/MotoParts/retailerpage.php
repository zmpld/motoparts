<?php 
include_once("config.php");

session_start();
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'retailer') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "user_registration");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch Orders using correct column name
$pending_orders = $conn->query("SELECT orders.*, users.first_name, users.last_name 
FROM orders 
INNER JOIN users ON orders.customer_email = users.email 
WHERE orders.order_status = 'Pending'");

$shipped_orders = $conn->query("SELECT orders.*, users.first_name, users.last_name 
FROM orders 
INNER JOIN users ON orders.customer_email = users.email 
WHERE orders.order_status = 'Shipped'");

$unshipped_orders = $conn->query("SELECT orders.*, users.first_name, users.last_name 
FROM orders 
INNER JOIN users ON orders.customer_email = users.email 
WHERE orders.order_status = 'Unshipped'");

$delivered_orders = $conn->query("SELECT orders.*, users.first_name, users.last_name 
FROM orders 
INNER JOIN users ON orders.customer_email = users.email 
WHERE orders.order_status = 'Delivered'");

// Fetch sales data for today and last 7 days
$sales_today = $conn->query("SELECT COUNT(*) AS total FROM sales WHERE sales_date = CURDATE()")->fetch_assoc() ?: ['total' => 0];
$sales_week = $conn->query("SELECT COUNT(*) AS total FROM sales WHERE sales_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)")->fetch_assoc() ?: ['total' => 0];

// Sales by Seller Fulfilled
$sales_seller_fulfilled_today = $conn->query("SELECT COUNT(*) AS total FROM sales WHERE sales_date = CURDATE() AND fulfilled_by = 'Seller'")->fetch_assoc() ?: ['total' => 0];
$sales_seller_fulfilled_week = $conn->query("SELECT COUNT(*) AS total FROM sales WHERE sales_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND fulfilled_by = 'Seller'")->fetch_assoc() ?: ['total' => 0];

// Sales by MT Motorcycle Parts
$sales_mt_fulfilled_today = $conn->query("SELECT COUNT(*) AS total FROM sales WHERE sales_date = CURDATE() AND fulfilled_by = 'MT Motorcycle Parts'")->fetch_assoc() ?: ['total' => 0];
$sales_mt_fulfilled_week = $conn->query("SELECT COUNT(*) AS total FROM sales WHERE sales_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND fulfilled_by = 'MT Motorcycle Parts'")->fetch_assoc() ?: ['total' => 0];

// Fetch payment summary (balance)
$payment = $conn->query("SELECT balance FROM payment_summary LIMIT 1")->fetch_assoc() ?: ['balance' => 0];

if (!$pending_orders || !$shipped_orders || !$unshipped_orders || !$delivered_orders) {
    die("Error fetching order data: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotoParts Manager - Retailer</title>
    <link rel="stylesheet" href="retailerstyle.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="retailerstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <script src="script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
</head>

<body>

<!----- NAVBAR ---------- NAVBAR ---------- NAVBAR ----->
<nav class="navbar">
    <div class="navdiv">
        <div class="logo">
            <img src="assets/logo.jpg" alt="MotoParts Manager">
        </div>
        <ul style="padding-top: 20px; padding-right: 20px;">
            <li><a class="hac active" href="#">Home</a></li>
            <li><a class="hac" href="about_retailer.html">About</a></li>
            <li class="dropdown"><a class="hac" href="#" id="contactLink">Contact</a>
                <ul class="dropdown_menu" id="contactDropdown">
                    <li><i class='bx bx-phone'></i> (+63) 9298642708</li>
                    <li><i class='bx bx-envelope'></i> mtmotoparts@gmail.com</li>
                </ul>
            </li>
            <li><a class="hac active" href="logout.php" style="display: inline-block; padding: 12px 40px; min-width: 125%; text-align: center;"><i class='bx bx-log-out'></i> Log Out</a></li>
        </ul>
    </div>
</nav>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const contactLink = document.getElementById("contactLink");
    const contactDropdown = document.getElementById("contactDropdown");

    if (contactLink && contactDropdown) {
        contactLink.addEventListener("click", function (event) {
            event.preventDefault();
            contactDropdown.classList.toggle("open");
        });

        // Close dropdown when clicking outside
        document.addEventListener("click", function (event) {
            if (!contactLink.contains(event.target) && !contactDropdown.contains(event.target)) {
                contactDropdown.classList.remove("open");
            }
        });
    } else {
        console.error("Contact elements not found in the DOM.");
    }
});
</script>

<div class="container">
    <!-- Order Update Form -->
    <form action="update_order.php" method="post" class="order-update-form">
        <fieldset style="border-radius: 7px;">
            <legend>Update Order Details</legend>

            <div class="form-group">
                <label for="order_id">Order ID:</label>
                <input style="width: 98%;" type="number" id="order_id" name="order_id" required placeholder="Enter Order ID">
            </div>

            <div class="form-group">
                <label for="order_status">Order Status:</label>
                <select id="order_status" name="order_status">
                    <option value="" disabled selected>Select Order Status</option>
                    <option value="Pending">Pending</option>
                    <option value="Shipped">Shipped</option>
                    <option value="Unshipped">Unshipped</option>
                    <option value="Delivered">Delivered</option>
                </select>
            </div>

        <div class="form-group">
            <label for="payment_status">Payment Status:</label>
            <select id="payment_status" name="payment_status">
                <option value="" disabled selected>Select Payment Status</option>
                <option value="Unpaid">Unpaid</option>
                <option value="Paid">Paid</option>
                <option value="Refunded">Refunded</option>
            </select>
        </div>

        <div class="form-group">
            <label for="shipping_date">Shipping Date:</label>
            <input style="width: 98%;" type="date" id="shipping_date" name="shipping_date">
        </div>
        <br>
        <button type="submit" class="save-btn">Update Order</button>

    </fieldset>
</form>

<!-- YOUR ORDERS  -->
    <div class="orders-section">
        <h1>Pending Orders</h1>
        <table style="background-color: #fa934e;">
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Total Price</th>
            </tr>
            <?php
            if ($pending_orders) {
                while ($row = $pending_orders->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['order_id'] . '</td>';
                    echo '<td>' . (isset($row['first_name']) ? $row['first_name'] : 'N/A') . ' ' . (isset($row['last_name']) ? $row['last_name'] : 'N/A') . '</td>';
                    echo '<td>' . $row['product_name'] . '</td>';
                    echo '<td>' . $row['quantity'] . '</td>';
                    echo '<td>Php ' . number_format($row['total_price'], 2) . '</td>';
                    echo '</tr>';
                }
            } else {
                echo "Error fetching pending orders.";
            }
            ?>
        </table>
    </div>
<!-- SHIPPED ORDERS -->
<div class="orders-section">
    <h1>Shipped Orders</h1>
    <table style="background-color: #fa934e;">
        <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Total Price</th>
        </tr>
        <?php while ($row = $shipped_orders->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['order_id'] ?></td>
                <td><?= isset($row['first_name']) ? $row['first_name'] : 'N/A' ?> <?= isset($row['last_name']) ? $row['last_name'] : 'N/A' ?></td>
                <td><?= $row['product_name'] ?></td>
                <td><?= $row['quantity'] ?></td>
                <td>Php <?= number_format($row['total_price'], 2) ?></td>
            </tr>
        <?php } ?>
    </table>
</div>

<!-- UNSHIPPED ORDERS -->
<div class="orders-section">
    <h1>Unshipped Orders</h1>
    <table style="background-color: #fa934e;">
        <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Total Price</th>
        </tr>
        <?php while ($row = $unshipped_orders->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['order_id'] ?></td>
                <td><?= isset($row['first_name']) ? $row['first_name'] : 'N/A' ?> <?= isset($row['last_name']) ? $row['last_name'] : 'N/A' ?></td>
                <td><?= $row['product_name'] ?></td>
                <td><?= $row['quantity'] ?></td>
                <td>Php <?= number_format($row['total_price'], 2) ?></td>
            </tr>
        <?php } ?>
    </table>
</div>

<!-- DELIVERED ORDERS -->
<div class="orders-section">
    <h1>Delivered Orders</h1>
    <table style="background-color: #fa934e;">
        <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Total Price</th>
        </tr>
        <?php while ($row = $delivered_orders->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['order_id'] ?></td>
                <td><?= isset($row['first_name']) ? $row['first_name'] : 'N/A' ?> <?= isset($row['last_name']) ? $row['last_name'] : 'N/A' ?></td>
                <td><?= $row['product_name'] ?></td>
                <td><?= $row['quantity'] ?></td>
                <td>Php <?= number_format($row['total_price'], 2) ?></td>
            </tr>
        <?php } ?>
    </table>
</div>

<style>
table th {
    background-color: #11132a;
}
table tr:first-child th {
        color: white;
    }

table th:first-child tr {
        background-color: white;
    }

    table tr {
        color: black;
    }
</style>

<!-- Sales and Payment Summary -->
<div class="info-section">
    <h2>Seller Fulfilled</h2>
    <p>In last day: <?= $sales_seller_fulfilled_today['total'] ?></p>
    <p>In last 7 days: <?= $sales_seller_fulfilled_week['total'] ?></p>

    <h2>Fulfilled by MT Motorcycle Parts</h2>
    <p>In last day: <?= $sales_mt_fulfilled_today['total'] ?></p>
    <p>In last 7 days: <?= $sales_mt_fulfilled_week['total'] ?></p>

    <h2>Payment Summary</h2>
    <p>Balance: Php <?= number_format($payment['balance'], 2) ?></p>
</div>


<!-- Announcements -->
<div class="announcement-box">
    Announcement:<br>
    Important update here.
</div>

<!-- Product Upload Form -->
<div class="form-section">
    <h2>What products do you want to sell?</h2>
    <form action="upload_product.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="product-name">Product Title:</label>
            <input style="width: 98%; height: 20px;" type="text" name="product_name" id="product-name" required>
        </div>
        <div class="form-group">
            <label for="product-desc">Product Description:</label>
            <input style="width: 98%; height: 60px;" type="text" name="product_desc" id="product-desc" required>
        </div>
        <div class="form-group">
            <label for="category">Category:</label>
            <select id="category" name="category" required>
                <option value="" disabled selected>Select Category</option>
                <option value="sprockets_and_chains">Sprockets & Chains</option>
                <option value="wheels_and_tires">Wheels & Tires</option>
                <option value="lubricants_and_oils">Lubricants & Oils</option>
                <option value="braking_systems">Braking Systems</option>
                <option value="engines_and_transmissions">Engines & Transmissions</option>
                <option value="batteries_and_electrical">Batteries & Electrical</option>
            </select>
        </div>
        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input style="width: 98%;" type="number" id="quantity" name="quantity" step="1" min="0" required placeholder="Enter Quantity">
        </div>
        <div class="form-group">
            <label for="unit_price">Unit Price (Php):</label>
            <input style="width: 98%;" type="number" id="unit_price" name="unit_price" step="0.01" min="0" required placeholder="Enter Unit Price (e.g., 99.99)">
        </div>
        <div class="form-group">
            <label for="upload">Product Image:</label>
            <input type="file" name="upload" id="upload" accept="image/*" required>
        </div>
        <button type="submit" class="save-btn">Add Product</button>
    </form>
</div>



</div>

    <section class="footer">
        &copy; <b style="font-family: 'Poppins', sans-serif;">MotoParts Manager </b>2025. All rights reserved.<br><br>
        Developed by Mapalad, Morales, & SIGUA | CSS152L_AM5 | Software Engineering 2<br><br>
        This Website is Made for MT Moto Cycle Parts Business | MOTO PARTS MANAGER<br><br>
        <a style="font-size: 30px; margin: 10px;" class="hac" href="https://www.facebook.com/motocycleparts" target="_blank"><i class='bx bxl-facebook-circle'></i></a>
        <a style="font-size: 30px; margin: 10px;" class="hac" href="https://mail.google.com/mail/" target="_blank"><i class='bx bx-envelope'></i></a>
        <a style="font-size: 30px; margin: 10px;" class="hac" href="https://www.linkedin.com/in/your-profile" target="_blank"><i class='bx bxl-linkedin'></i></a>
    </section>


</body>
</html>

