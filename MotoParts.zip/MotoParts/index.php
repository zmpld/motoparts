<?php  
session_start();
include 'config.php'; 

$customer_email = $_SESSION['customer_email'] ?? null;
$username = $customer_email ?? "Not Logged In";

// Handle Add to Cart AJAX request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_cart') {
    if (!$customer_email) {
        echo json_encode(['status' => 'redirect', 'location' => 'login.php']);
        exit();
    }

    $inventory_id = intval($_POST['inventory_id']);
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

    $stmt = $conn->prepare("SELECT cart_id, quantity FROM cart WHERE email = ? AND inventory_id = ?");
    $stmt->bind_param("si", $customer_email, $inventory_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $new_quantity = $row['quantity'] + $quantity;

        $update_stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE cart_id = ?");
        $update_stmt->bind_param("ii", $new_quantity, $row['cart_id']);
        $update_stmt->execute();
        $update_stmt->close();
    } else {
        $insert_stmt = $conn->prepare("INSERT INTO cart (email, inventory_id, quantity) VALUES (?, ?, ?)");
        $insert_stmt->bind_param("sii", $customer_email, $inventory_id, $quantity);
        $insert_stmt->execute();
        $insert_stmt->close();
    }

    $stmt->close();

    echo json_encode(['status' => 'success', 'message' => 'Item added to cart successfully!']);
    exit();
}

$selectedCategory = $_GET['category'] ?? '';

$searchKeyword = $_GET['search'] ?? '';

if ($selectedCategory && $searchKeyword) {
    $query = "SELECT inventory_id, product_name, product_desc, unit_price, image_path, category FROM inventory WHERE category = ? AND product_name LIKE ?";
    $stmt = $conn->prepare($query);
    $likeSearch = "%$searchKeyword%";
    $stmt->bind_param("ss", $selectedCategory, $likeSearch);
} elseif ($selectedCategory) {
    $query = "SELECT inventory_id, product_name, product_desc, unit_price, image_path, category FROM inventory WHERE category = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $selectedCategory);
} elseif ($searchKeyword) {
    $query = "SELECT inventory_id, product_name, product_desc, unit_price, image_path, category FROM inventory WHERE product_name LIKE ?";
    $stmt = $conn->prepare($query);
    $likeSearch = "%$searchKeyword%";
    $stmt->bind_param("s", $likeSearch);
} else {
    $query = "SELECT inventory_id, product_name, product_desc, unit_price, image_path, category FROM inventory";
    $stmt = $conn->prepare($query);
}

$stmt->execute();
$stmt->bind_result($inventory_id, $product_name, $product_desc, $unit_price, $image_path, $category);

while ($stmt->fetch()) {
    $items[] = [
        'inventory_id' => $inventory_id,
        'product_name' => $product_name,
        'product_desc' => $product_desc,
        'unit_price' => $unit_price,
        'image_path' => $image_path,
        'category' => $category
    ];
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MotoParts Manager</title>
<link rel="stylesheet" href="i.css">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<script src="script.js"></script>
<link rel="icon" href="assets/logo.jpg" type="image/x-icon">

</head>

<body>

<?php if (isset($_SESSION['order_success'])): ?>
    <div id="orderSuccessMsg" class="message success" style="display:block;">
        <i class='bx bx-check-circle'></i> <?= $_SESSION['order_success']; ?>
    </div>
    <script>
        setTimeout(() => {
            const msg = document.getElementById("orderSuccessMsg");
            if (msg) msg.style.display = "none";
        }, 4000);
    </script>
    <?php unset($_SESSION['order_success']); ?>
<?php endif; ?>

<div id="message" class="message"></div>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="navdiv">
        <div class="logo">
            <img src="assets/logo.jpg" alt="MotoParts Manager">
        </div>
        <ul style="padding-top: 20px; margin-left: 50px;">
            <li class="search">
                <span style="color: #fa934e; font-weight: 600; margin-right: 10px;">
                    <i class='bx bx-search'></i> Search:
                </span>
                <form id="searchForm" method="GET" action="index.php" style="display:inline;">
                    <input type="search" name="search" placeholder="Search products..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                </form>
            </li>
            <li><a class="hac active" href="#">Home</a></li>
            <li><a class="hac" href="about_index.html">About</a></li>
            <li class="dropdown"><a class="hac" href="#" id="contactLink">Contact</a>
                <ul class="dropdown_menu" id="contactDropdown">
                    <li><i class='bx bx-phone'></i> (+63) 9298642708</li>
                    <li><i class='bx bx-envelope'></i> mtmotoparts@gmail.com</li>
                </ul>
            </li>
            <li><a class="hac" href="customer_cart.php">Cart</a></li>
            <li><a class="hac" href="order_history.php">Orders</a></li>
            <li><a class="hac active" href="login.php" style="display: inline-block; padding: 12px 40px; min-width: 125%; text-align: center;">Login/Register</a></li>
        </ul>
    </div>
</nav>



<!-- Sub Navigation -->
<nav class="subBar">
    <div class="subdiv">
        <ul>
            <li><a class="hac category" href="#" data-filter=""><i class='bx bx-wrench'></i> General Parts</a></li>
            <li><a class="hac category" href="#" data-filter="sprockets_and_chains"><i class='bx bx-cog'></i> Sprockets & Chains</a></li>
            <li><a class="hac category" href="#" data-filter="wheels_and_tires"><i class='bx bx-trip'></i> Wheels & Tires</a></li>
            <li><a class="hac category" href="#" data-filter="lubricants_and_oils"><i class='bx bx-droplet'></i> Lubricants & Oils</a></li>
            <li><a class="hac category" href="#" data-filter="braking_systems"><i class='bx bx-shield'></i> Braking Systems</a></li>
            <li><a class="hac category" href="#" data-filter="engines_and_transmissions"><i class='bx bx-car'></i> Engines & Transmissions</a></li>
            <li><a class="hac category" href="#" data-filter="batteries_and_electrical"><i class='bx bx-battery'></i> Batteries & Electrical</a></li>
            <li class="socials">
                <a class="hac" href="https://www.facebook.com/motocycleparts" target="_blank">
                    <i class='bx bxl-facebook-circle'></i>
                </a>
            </li>
            <li class="socials">
                <a class="hac" href="https://mail.google.com/mail/" target="_blank">
                    <i class='bx bx-envelope'></i>
                </a>
            </li>
            <li class="socials">
                <a class="hac" href="https://www.linkedin.com/in/your-profile" target="_blank">
                    <i class='bx bxl-linkedin'></i>
                </a>
            </li>
            <li>
                <span style="color: #fa934e; font-weight: 600;">
                    <i class='bx bxs-location-plus'></i> Delivered To:
                </span> 
                <span style="color: #666; font-weight: 500;"><?php echo htmlspecialchars($username); ?></span>
            </li>
        </ul>
    </div>
</nav>

<!-- Main Content -->
<div class="MainBar">
    <div class="MainContent">
        <?php if (empty($items)): ?>
            <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px;">
                <i class='bx bx-package' style="font-size: 80px; color: #ddd; margin-bottom: 20px;"></i>
                <h3 style="color: #666; margin-bottom: 10px;">No products found</h3>
                <p style="color: #999;">Try selecting a different category or check back later.</p>
            </div>
        <?php else: ?>
            <?php foreach ($items as $item): ?>
                <div class="item1" data-category="<?= htmlspecialchars($item['category']); ?>" onclick="openModal(
                    <?= $item['inventory_id']; ?>,
                    '<?= htmlspecialchars(addslashes($item['product_name'])); ?>', 
                    '<?= htmlspecialchars(addslashes($item['product_desc'])); ?>', 
                    <?= $item['unit_price']; ?>, 
                    '<?= htmlspecialchars($item['image_path']); ?>'
                )">
                    <div>
                        <img src="<?= htmlspecialchars($item['image_path']); ?>" alt="<?= htmlspecialchars($item['product_name']); ?>">
                        <a><?= htmlspecialchars($item['product_name']); ?></a>
                        <a>₱<?= number_format($item['unit_price'], 2); ?></a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal -->
<div id="orderModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <div class="modal-body">
            <div class="modal-image">   
                <img id="modalProductImage" class="modal-img" src="" alt="Product Image">
            </div>
            <h2 id="modalProductName" class="modal-product-name"></h2>
            <p id="modalProductDesc" class="modal-product-desc"></p>
            <p id="modalProductPrice" class="modal-product-price"></p>
            
            <div class="quantity-section">
                <label for="quantity" class="quantity-label">
                    <i class='bx bx-package'></i> Quantity:
                </label>
                <input type="number" id="quantity" class="quantity-input" value="1" min="1" onchange="updateTotal()">
            </div>
            
            <div class="total-price">
                <i class='bx bx-calculator'></i> Total: ₱<span id="totalPrice"></span>
            </div>
            
            <div class="modal-buttons">
                <button onclick="submitOrder()" class="order-btn buy-now-btn">
                    <i class='bx bx-shopping-bag'></i> Buy Now
                </button>
                <button onclick="addToCartFromModal()" class="order-btn add-cart-btn">
                    <i class='bx bx-cart-add'></i> Add to Cart
                </button>
            </div>
        </div>
    </div>
</div>

<script>

document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.querySelector('#searchForm input[name="search"]');

    if (searchInput) {
        searchInput.addEventListener("keypress", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                document.getElementById("searchForm").submit();
            }
        });
    }
});


// Contact dropdown functionality
document.addEventListener("DOMContentLoaded", function () {
    const contactLink = document.getElementById("contactLink");
    const contactDropdown = document.getElementById("contactDropdown");

    contactLink.addEventListener("click", function (event) {
        event.preventDefault();
        contactDropdown.classList.toggle("open");
    });

    document.addEventListener("click", function (event) {
        if (!contactLink.contains(event.target) && !contactDropdown.contains(event.target)) {
            contactDropdown.classList.remove("open");
        }
    });
});

// Category filtering
const urlParams = new URLSearchParams(window.location.search);
const currentCategory = urlParams.get('category') || '';

document.querySelectorAll('.category').forEach(item => {
    if (item.getAttribute('data-filter') === currentCategory) {
        item.classList.add('active');
    }

    item.addEventListener('click', function() {
        document.querySelectorAll('.category').forEach(link => {
            link.classList.remove('active');
        });

        this.classList.add('active');
        const category = this.getAttribute('data-filter');
        window.location.href = `index.php?category=${category}`;
    });
});

// Modal and cart functionality
let currentPrice = 0;
let currentInventoryId = 0;

function showMessage(message, type = 'success') {
    const messageDiv = document.getElementById('message');
    messageDiv.innerHTML = `<i class='bx ${type === 'success' ? 'bx-check-circle' : 'bx-error-circle'}'></i> ${message}`;
    messageDiv.className = `message ${type}`;
    messageDiv.style.display = 'block';
    
    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 4000);
}

function openModal(inventoryId, productName, productDesc, price, imageSrc) {
    currentInventoryId = inventoryId;
    document.getElementById('modalProductName').innerText = productName;
    document.getElementById('modalProductDesc').innerText = productDesc;
    document.getElementById('modalProductPrice').innerText = `₱${price.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById('totalPrice').innerText = price.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    document.getElementById('modalProductImage').src = imageSrc;
    currentPrice = price;
    document.getElementById('quantity').value = 1;
    document.getElementById('orderModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('orderModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

function updateTotal() {
    let quantity = document.getElementById('quantity').value;
    document.getElementById('totalPrice').innerText = (quantity * currentPrice).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
}

function addToCartFromModal() {
    const quantity = document.getElementById('quantity').value;
    addToCart(currentInventoryId, quantity);
    closeModal();
}

function addToCart(inventoryId, quantity) {
    const formData = new FormData();
    formData.append('action', 'add_to_cart');
    formData.append('inventory_id', inventoryId);
    formData.append('quantity', quantity);

    fetch('index.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'redirect') {
            window.location.href = data.location;
        } else if (data.status === 'success') {
            showMessage(data.message, 'success');
        } else {
            showMessage('Error adding item to cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessage('Error adding item to cart', 'error');
    });
}

function submitOrder() {
    const inventoryId = currentInventoryId;
    const quantity = document.getElementById('quantity').value;

    if (!inventoryId || quantity < 1) {
        showMessage('Please select a valid product and quantity', 'error');
        return;
    }

    showMessage('Redirecting to login...', 'success');

    setTimeout(() => {
        const form = document.createElement("form");
        form.action = "login.php";
        form.method = "POST";
        form.style.display = "none";

        const fields = {
            inventory_id: inventoryId,
            quantity: quantity,
            from_modal: "true"
        };

        for (const [name, value] of Object.entries(fields)) {
            const input = document.createElement("input");
            input.type = "hidden";
            input.name = name;
            input.value = value;
            form.appendChild(input);
        }

        document.body.appendChild(form);
        form.submit();
    }, 800);
}
</script>

<section class="footer">
    &copy; <b style="font-family: 'Poppins', sans-serif;">MotoParts Manager </b>2025. All rights reserved.<br><br>
    Developed by Mapalad, Morales, & SIGUA | CSS152L_AM5 | Software Engineering 2<br><br>
    This Website is Made for MT Moto Cycle Parts Business | MOTO PARTS MANAGER<br><br>
    <a style="font-size: 30px; margin: 10px;" class="hac" href="https://www.facebook.com/motocycleparts" target="_blank"><i class='bx bxl-facebook-circle'></i></a>
    <a style="font-size: 30px; margin: 10px;" class="hac" href="https://mail.google.com/mail/" target="_blank"><i class='bx bx-envelope'></i></a>
    <a style="font-size: 30px; margin: 10px;" class="hac" href="https://www.linkedin.com/in/your-profile" target="_blank"><i class='bx bxl-linkedin'></i></a>
</section>

</body>
</html>