<?php
session_start();
include 'config.php';

if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

$customer_email = $_SESSION['email'];
$username = "Not Logged In";
$address = "Not Logged In";

// Get username and address
$stmt = $conn->prepare("SELECT username, address FROM users WHERE email = ?");
$stmt->bind_param("s", $customer_email);
$stmt->execute();
$stmt->bind_result($db_username, $db_address);
if ($stmt->fetch()) {
    $username = $db_username;
    $address = $db_address;
}
$stmt->close();

$cart_items = [];
$total_amount = 0;
$total_items = 0;
$from_modal = false;
$modal_inventory_id = 0;
$modal_quantity = 0;

if (isset($_POST['from_modal']) && $_POST['from_modal'] === 'true') {
    // Handle direct Buy Now
    $from_modal = true;
    $modal_inventory_id = intval($_POST['inventory_id']);
    $modal_quantity = intval($_POST['quantity']);

    $stmt = $conn->prepare("SELECT product_name, product_desc, unit_price, image_path FROM inventory WHERE inventory_id = ?");
    $stmt->bind_param("i", $modal_inventory_id);
    $stmt->execute();
    $stmt->bind_result($product_name, $product_desc, $unit_price, $image_path);

    if ($stmt->fetch()) {
        $subtotal = $unit_price * $modal_quantity;
        $cart_items[] = [
            'inventory_id' => $modal_inventory_id,
            'product_name' => $product_name,
            'product_desc' => $product_desc,
            'unit_price' => $unit_price,
            'quantity' => $modal_quantity,
            'image_path' => $image_path,
            'subtotal' => $subtotal
        ];
        $total_amount = $subtotal;
        $total_items = $modal_quantity;
    }
    $stmt->close();
} else {
    // Fetch full cart
    $stmt = $conn->prepare("
        SELECT c.cart_id, c.inventory_id, c.quantity,
               i.product_name, i.product_desc, i.unit_price, i.image_path
        FROM cart c
        JOIN inventory i ON c.inventory_id = i.inventory_id
        WHERE c.email = ?
    ");
    $stmt->bind_param("s", $customer_email);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $row['subtotal'] = $row['unit_price'] * $row['quantity'];
        $total_amount += $row['subtotal'];
        $total_items += $row['quantity'];
        $cart_items[] = $row;
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout - MotoParts Manager</title>
    <link rel="stylesheet" href="i.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: white;
            min-height: 100vh;
            padding: 20px 0;
        }
        
        .checkout-container {
            max-width: 1000px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .checkout-header {
            background: linear-gradient(135deg, #4a5568 0%, #2d3748 100%);
            color: white;
            padding: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .checkout-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(250, 147, 78, 0.1) 0%, transparent 70%);
            animation: pulse 4s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.1; }
            50% { transform: scale(1.1); opacity: 0.2; }
        }
        
        .checkout-header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            position: relative;
            z-index: 1;
        }
        
        .checkout-header h1 i {
            color: #fa934e;
            font-size: 36px;
        }
        
        .customer-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            position: relative;
            z-index: 1;
        }
        
        .customer-info p {
            background: rgba(255, 255, 255, 0.1);
            padding: 12px 18px;
            border-radius: 10px;
            border-left: 4px solid #fa934e;
            font-weight: 500;
        }
        
        .checkout-content {
            padding: 30px;
        }
        
        .order-summary {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .order-summary h2 {
            color: #2d3748;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .order-summary h2 i {
            color: #fa934e;
        }
        
        .item {
            display: grid;
            grid-template-columns: 100px 1fr;
            gap: 20px;
            padding: 20px 0;
            border-bottom: 1px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        
        .item:last-child {
            border-bottom: none;
        }
        
        .item:hover {
            background: rgba(250, 147, 78, 0.02);
            border-radius: 10px;
            padding: 20px;
            margin: 0 -20px;
        }
        
        .item img {
            width: 100%;
            height: 100px;
            object-fit: cover;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .item-details h4 {
            color: #2d3748;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .item-details p {
            color: #718096;
            font-size: 14px;
            margin-bottom: 8px;
            line-height: 1.5;
        }
        
        .item-price {
            color: #fa934e;
            font-weight: 600;
            font-size: 15px;
        }
        
        .total-section {
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        
        .total-summary {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .total-item {
            background: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }
        
        .total-item h3 {
            color: #718096;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .total-item p {
            color: #2d3748;
            font-size: 24px;
            font-weight: 700;
        }
        
        .total-amount {
            border: 2px solid #fa934e;
            background: linear-gradient(135deg, rgba(250, 147, 78, 0.1) 0%, rgba(250, 147, 78, 0.05) 100%);
        }
        
        .total-amount p {
            color: #fa934e;
        }
        
        .payment-section {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }
        
        .payment-section h3 {
            color: #2d3748;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .payment-section h3 i {
            color: #fa934e;
        }
        
        .payment-section label {
            display: block;
            margin-bottom: 10px;
            font-weight: 500;
            color: #4a5568;
        }
        
        .payment-section select {
            width: 100%;
            padding: 15px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 500;
            background: white;
            color: #2d3748;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }
        
        .payment-section select:focus {
            outline: none;
            border-color: #fa934e;
            box-shadow: 0 0 0 3px rgba(250, 147, 78, 0.1);
        }
        
        .btn-place-order {
            background: linear-gradient(135deg, #38a169 0%, #2f855a 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(56, 161, 105, 0.3);
            display: flex;
            align-items: center;
            gap: 10px;
            justify-content: center;
            width: 100%;
        }
        
        .btn-place-order:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(56, 161, 105, 0.4);
        }
        
        .btn-place-order:active {
            transform: translateY(0);
        }
        
        .btn-back {
            background: linear-gradient(135deg, #718096 0%, #4a5568 100%);
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(113, 128, 150, 0.3);
        }
        
        .btn-back:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(113, 128, 150, 0.4);
        }
        
        .empty-checkout {
            text-align: center;
            padding: 60px 30px;
            color: #718096;
        }
        
        .empty-checkout i {
            font-size: 80px;
            color: #e2e8f0;
            margin-bottom: 20px;
        }
        
        .empty-checkout h2 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #4a5568;
        }
        
        .empty-checkout a {
            color: #fa934e;
            text-decoration: none;
            font-weight: 600;
        }
        
        .empty-checkout a:hover {
            text-decoration: underline;
        }
        
        .checkout-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        @media (max-width: 768px) {
            .customer-info {
                grid-template-columns: 1fr;
            }
            
            .total-summary {
                grid-template-columns: 1fr;
            }
            
            .item {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .checkout-actions {
                flex-direction: column;
                align-items: stretch;
            }
            
            .btn-place-order,
            .btn-back {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="checkout-container">
        <div class="checkout-header">
            <h1><i class='bx bx-credit-card'></i> Checkout Summary</h1>
            <div class="customer-info">
                <p><strong>Customer:</strong> <?= htmlspecialchars($username); ?></p>
                <p><strong>Delivery Address:</strong> <?= htmlspecialchars($address); ?></p>
            </div>
        </div>
        
        <div class="checkout-content">
            <?php if (empty($cart_items)): ?>
                <div class="empty-checkout">
                    <i class='bx bx-cart-alt'></i>
                    <h2>No items to checkout</h2>
                    <p>Your cart is empty. Start shopping to add items.</p>
                    <br>
                    <a href="customerpage.php" class="btn-back">
                        <i class='bx bx-store'></i> Go back to shopping
                    </a>
                </div>
            <?php else: ?>
                <div class="order-summary">
                    <h2><i class='bx bx-list-ul'></i> Order Summary</h2>
                    <?php foreach ($cart_items as $item): ?>
                        <div class="item">
                            <img src="<?= htmlspecialchars($item['image_path']); ?>" alt="<?= htmlspecialchars($item['product_name']); ?>">
                            <div class="item-details">
                                <h4><?= htmlspecialchars($item['product_name']); ?></h4>
                                <p><?= htmlspecialchars($item['product_desc']); ?></p>
                                <p class="item-price">
                                    Qty: <?= $item['quantity']; ?> × ₱<?= number_format($item['unit_price'], 2); ?> = 
                                    ₱<?= number_format($item['subtotal'], 2); ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="total-section">
                    <div class="total-summary">
                        <div class="total-item">
                            <h3>Total Items</h3>
                            <p><?= $total_items; ?></p>
                        </div>
                        <div class="total-item total-amount">
                            <h3>Total Amount</h3>
                            <p>₱<?= number_format($total_amount, 2); ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="payment-section">
                    <h3><i class='bx bx-wallet'></i> Payment Method</h3>
                    
                    <form action="submit_order.php" method="post">
                        <input type="hidden" name="from_checkout" value="true">
                        <input type="hidden" name="from_modal" value="<?= $from_modal ? 'true' : 'false'; ?>">
                        
                        <?php if ($from_modal): ?>
                            <!-- Include the inventory_id and quantity for Buy Now orders -->
                            <input type="hidden" name="inventory_id" value="<?= $modal_inventory_id; ?>">
                            <input type="hidden" name="quantity" value="<?= $modal_quantity; ?>">
                        <?php endif; ?>
                        
                        <label for="payment">Choose your preferred payment method:</label>
                        <select name="payment_method" id="payment" required>
                            <option value="">Select Payment Method</option>
                            <option value="COD">💵 Cash On Delivery</option>
                            <option value="PayRex">🔒 Pay with PayRex</option>
                        </select>
                        
                        <button type="submit" class="btn-place-order">
                            <i class='bx bx-check-circle'></i> Place Order
                        </button>
                    </form>
                </div>
                
                <div class="checkout-actions">
                    <?php if ($from_modal): ?>
                        <a href="customerpage.php" class="btn-back">
                            <i class='bx bx-arrow-back'></i> Back to Products
                        </a>
                    <?php else: ?>
                        <a href="customer_cart.php" class="btn-back">
                            <i class='bx bx-arrow-back'></i> Back to Cart
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
