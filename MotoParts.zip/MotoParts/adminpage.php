<?php
include_once("config.php");

session_start();
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_POST['add_expense'])) {
    $amount = $_POST['amount'];
    $description = $_POST['description'];
    $expense_date = $_POST['expense_date'];

    // Insert into expenses table
    $insert_query = "INSERT INTO expenses (amount, description, expense_date) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $insert_query);
    mysqli_stmt_bind_param($stmt, "dss", $amount, $description, $expense_date);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Expense added successfully!'); window.location.href='adminpage.php';</script>";
    } else {
        echo "<script>alert('Failed to add expense.');</script>";
    }

    mysqli_stmt_close($stmt);
}

//----- STATISTICS -----//
//Fetch total sales revenue
$sales_query = "SELECT SUM(total_price) AS total_sales FROM orders";
$sales_result = mysqli_query($conn, $sales_query);
$sales_data = mysqli_fetch_assoc($sales_result);
$total_sales = $sales_data['total_sales'] ?? 0;

//Fetch total expenses
$expense_query = "SELECT COALESCE(SUM(amount), 0) AS total_expenses FROM expenses";
$expense_result = mysqli_query($conn, $expense_query);
$expense_data = mysqli_fetch_assoc($expense_result);
$total_expenses = $expense_data['total_expenses'] ?? 0;

//Calculate profit
$profit = $total_sales - $total_expenses;

//Fetch product sales analytics (10 most recent)
$product_sales_query = "SELECT product_name, SUM(quantity) AS total_sold, SUM(total_price) AS revenue
                        FROM orders 
                        GROUP BY product_name
                        ORDER BY MAX(order_date) DESC
                        LIMIT 10";
$product_sales_result = mysqli_query($conn, $product_sales_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotoParts Manager - Admin</title>
    <link rel="stylesheet" href="adminstyle.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="adminstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <script src="script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
</head>

<body>
<!----- NAVBAR ---------- NAVBAR ---------- NAVBAR ----->
<nav class="navbar">
    <div class="navdiv">
        <div class="logo">
            <img src="assets/logo.jpg" alt="MotoParts Manager">
        </div>
        <ul style="padding-top: 20px; padding-right: 20px;">
            <li><a class="hac active" href="#">Home</a></li>
            <li><a class="hac" href="about_admin.html">About</a></li>
            <li class="dropdown"><a class="hac" href="#" id="contactLink">Contact</a>
                <ul class="dropdown_menu" id="contactDropdown">
                    <li><i class='bx bx-phone'></i> (+63) 9298642708</li>
                    <li><i class='bx bx-envelope'></i> mtmotoparts@gmail.com</li>
                </ul>
            </li>
            <li><a class="hac active" href="logout.php" style="display: inline-block; padding: 12px 40px; min-width: 125%; text-align: center;"><i class='bx bx-log-out'></i> Log Out</a></li>
        </ul>
    </div>
</nav>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const contactLink = document.getElementById("contactLink");
    const contactDropdown = document.getElementById("contactDropdown");

    if (contactLink && contactDropdown) {
        contactLink.addEventListener("click", function (event) {
            event.preventDefault();
            contactDropdown.classList.toggle("open");
        });

        // Close dropdown when clicking outside
        document.addEventListener("click", function (event) {
            if (!contactLink.contains(event.target) && !contactDropdown.contains(event.target)) {
                contactDropdown.classList.remove("open");
            }
        });
    } else {
        console.error("Contact elements not found in the DOM.");
    }
});
</script>

<!----- SUBBAR ---------- SUBBAR ---------- SUBBAR ----->
<nav class="subBar">
    <div class="subdiv">
        <ul>
            <li><a class="hac" href="product_sales.php">Product Sales Analytics</a></li>
            <li><a class="hac" href="inventory_status.php">Inventory Status</a></li>
            <li><a class="hac" href="users.php">Users</a></li>
            <li><a class="hac" href="orders.php">Orders</a></li>
            <li><a class="hac" href="business_report.php">Business Report</a></li>
            <!-- <li><a class="hac" href="archive_logs.php">Archive Logs</a></li> -->
        </ul>
    </div>
</nav>

<!----- MAINBAR ---------- MAINBAR ---------- MAINBAR ----->
<nav class="MainBar">
    <div class="dashBoardadmin">
        <div class="insights">
            <!-- Sales Card -->
            <div class="stat-card">
                <h3>Total Sales</h3>
                <h1>Php <?php echo number_format($total_sales, 2); ?></h1>
                <canvas id="salesChart"></canvas>
            </div>

            <!-- Expenses Card -->
            <div class="stat-card">
                <h3>Total Expenses</h3>
                <h1>Php <?php echo number_format($total_expenses, 2); ?></h1>
                <canvas id="expensesChart"></canvas>
            </div>

            <!-- Profit Card -->
            <div class="stat-card">
                <h3>Net Profit</h3>
                <h1 class="net-profit">Php <?php echo number_format($profit, 2); ?></h1>
                <canvas id="profitChart"></canvas>
            </div>
        </div>
    </div>
</nav>

<script>
document.addEventListener("DOMContentLoaded", function () {
    //Detect Negative Profit
    let netProfit = document.querySelector(".net-profit");
    if (netProfit) {
        let profitValue = parseFloat(netProfit.innerText.replace("Php", "").replace(",", ""));
        if (profitValue < 0) {
            netProfit.classList.add("negative");
        }
    }

    //Sales Chart
    new Chart(document.getElementById("salesChart"), {
        type: 'bar',
        data: {
            labels: ["Sales"],
            datasets: [{
                label: "Php",
                data: [<?php echo $total_sales; ?>],
                backgroundColor: "blue"
            }]
        }
    });

    //Expenses Chart
    new Chart(document.getElementById("expensesChart"), {
        type: 'bar',
        data: {
            labels: ["Expenses"],
            datasets: [{
                label: "Php",
                data: [<?php echo $total_expenses; ?>],
                backgroundColor: "orange"
            }]
        }
    });

    //Profit Chart
    new Chart(document.getElementById("profitChart"), {
        type: 'bar',
        data: {
            labels: ["Profit"],
            datasets: [{
                label: "Php",
                data: [<?php echo $profit; ?>],
                backgroundColor: "<?php echo ($profit < 0) ? 'red' : 'green'; ?>"
            }]
        }
    });
});
</script>


<!-- Expense Entry Form -->
<h1 style="margin-left: 5%;">Add Expense</h1>
<form action="" method="POST" style="margin-left: 5%; margin-bottom: 20px; max-width: 500px;">
    <label for="amount">Amount:</label><br>
    <input type="number" name="amount" step="0.01" required><br><br>

    <label for="description">Description:</label><br>
    <input type="text" name="description" required><br><br>

    <label for="expense_date">Date:</label><br>
    <input type="date" name="expense_date" required><br><br>

    <button type="submit" name="add_expense">Add Expense</button>
</form>

<!----- TABLES ---------- TABLES ---------- TABLES ----->
<!----- Product Sales Analytics ----->
<h1 id="psa" style="margin-left: 5%; margin-bottom: -0.5%;">Recent Product Sales</h1>
<table class="custom-table">
    <thead>
        <tr>
            <th>Product Name</th>
            <th>Total Sold</th>
            <th>Revenue</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = mysqli_fetch_assoc($product_sales_result)): ?>
            <tr>
                <td><?php echo $row['product_name']; ?></td>
                <td><?php echo $row['total_sold']; ?></td>
                <td>Php <?php echo number_format($row['revenue'], 2); ?></td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<section class="footer">
    &copy; <b style="font-family: 'Poppins', sans-serif;">MotoParts Manager </b>2025. All rights reserved.<br><br>
    Developed by Mapalad, Morales, & SIGUA | CSS152L_AM5 | Software Engineering 2<br><br>
    This Website is Made for MT Moto Cycle Parts Business | MOTO PARTS MANAGER<br><br>
    <a style="font-size: 30px; margin: 10px;" class="hac" href="https://www.facebook.com/motocycleparts" target="_blank"><i class='bx bxl-facebook-circle'></i></a>
    <a style="font-size: 30px; margin: 10px;" class="hac" href="https://mail.google.com/mail/" target="_blank"><i class='bx bx-envelope'></i></a>
    <a style="font-size: 30px; margin: 10px;" class="hac" href="https://www.linkedin.com/in/your-profile" target="_blank"><i class='bx bxl-linkedin'></i></a>
</section>

<a href="business_report.php" style="display:inline-block; margin: 10px 0; padding: 8px 12px; background-color: #007bff; color: white; text-decoration: none; border-radius: 4px;">View Business Report</a>
</body>
</html>
