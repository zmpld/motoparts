CREATE TABLE IF NOT EXISTS action_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    retailer_id INT NULL,
    action_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_retailer_id (retailer_id),
    INDEX idx_action_type (action_type),
    INDEX idx_created_at (created_at)
);
