<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "user_registration";

// Create a connection
$conn = new mysqli($host, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4 for better security
$conn->set_charset("utf8mb4");
?>
