<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

session_start();
include 'config.php';

// Admin-only authentication
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    die("Unauthorized access");
}

// Fetch all orders and summaries
$stmt = $conn->prepare("SELECT order_id, customer_email, product_name, quantity, total_price, order_date, 
    order_status, payment_status, shipping_date, tracking_number, payment_method, Order_Address, created_at 
    FROM orders ORDER BY order_date DESC");
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

// Get product sales summary
$productQuery = "SELECT product_name, 
    COUNT(*) as order_count,
    SUM(quantity) as total_quantity, 
    SUM(total_price) as total_sales 
    FROM orders 
    GROUP BY product_name 
    ORDER BY total_sales DESC";
$productResult = $conn->query($productQuery);
$productSales = [];
while ($row = $productResult->fetch_assoc()) {
    $productSales[] = $row;
}

// Get category sales summary
$categoryQuery = "SELECT category, 
    COUNT(*) as order_count,
    SUM(orders.quantity) as total_quantity, 
    SUM(total_price) as total_sales 
    FROM orders 
    JOIN inventory ON orders.product_name = inventory.product_name 
    GROUP BY category 
    ORDER BY total_sales DESC";
$categoryResult = $conn->query($categoryQuery);
$categorySales = [];
while ($row = $categoryResult->fetch_assoc()) {
    $categorySales[] = $row;
}

$stmt->close();
$conn->close();

// Check if there are orders to export
if (empty($orders)) {
    die("No orders found for export.");
}

$format = $_GET['format'] ?? 'pdf';

if ($format === 'excel') {
    try {
        $spreadsheet = new Spreadsheet();
        
        // Orders Sheet
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle("All Orders");

        $headers = [
            'Order ID', 'Customer Email', 'Product Name', 'Quantity', 'Total Price', 'Order Date', 
            'Order Status', 'Payment Status', 'Payment Method', 'Shipping Date', 
            'Tracking Number', 'Address', 'Created At'
        ];
        $sheet->fromArray($headers, null, 'A1');

        // Style headers
        $headerStyle = [
            'font' => ['bold' => true],
            'fill' => [
                'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E2E8F0']
            ]
        ];
        $sheet->getStyle('A1:M1')->applyFromArray($headerStyle);

        // Add orders data
        $rowIndex = 2;
        foreach ($orders as $order) {
            $sheet->setCellValue("A{$rowIndex}", $order['order_id']);
            $sheet->setCellValue("B{$rowIndex}", $order['customer_email']);
            $sheet->setCellValue("C{$rowIndex}", $order['product_name']);
            $sheet->setCellValue("D{$rowIndex}", $order['quantity']);
            $sheet->setCellValue("E{$rowIndex}", $order['total_price']);
            $sheet->setCellValue("F{$rowIndex}", $order['order_date']);
            $sheet->setCellValue("G{$rowIndex}", $order['order_status']);
            $sheet->setCellValue("H{$rowIndex}", $order['payment_status']);
            $sheet->setCellValue("I{$rowIndex}", $order['payment_method']);
            $sheet->setCellValue("J{$rowIndex}", $order['shipping_date'] ?? 'N/A');
            $sheet->setCellValue("K{$rowIndex}", $order['tracking_number'] ?? 'N/A');
            $sheet->setCellValue("L{$rowIndex}", $order['Order_Address']);
            $sheet->setCellValue("M{$rowIndex}", $order['created_at']);
            $rowIndex++;
        }

        // Product Sales Sheet
        $productSheet = $spreadsheet->createSheet();
        $productSheet->setTitle("Product Sales");
        
        $productHeaders = ['Product Name', 'Order Count', 'Total Quantity', 'Total Sales'];
        $productSheet->fromArray($productHeaders, null, 'A1');
        $productSheet->getStyle('A1:D1')->applyFromArray($headerStyle);
        
        $rowIndex = 2;
        foreach ($productSales as $product) {
            $productSheet->setCellValue("A{$rowIndex}", $product['product_name']);
            $productSheet->setCellValue("B{$rowIndex}", $product['order_count']);
            $productSheet->setCellValue("C{$rowIndex}", $product['total_quantity']);
            $productSheet->setCellValue("D{$rowIndex}", $product['total_sales']);
            $rowIndex++;
        }

        // Category Sales Sheet
        $categorySheet = $spreadsheet->createSheet();
        $categorySheet->setTitle("Category Sales");
        
        $categoryHeaders = ['Category', 'Order Count', 'Total Quantity', 'Total Sales'];
        $categorySheet->fromArray($categoryHeaders, null, 'A1');
        $categorySheet->getStyle('A1:D1')->applyFromArray($headerStyle);
        
        $rowIndex = 2;
        foreach ($categorySales as $category) {
            $categorySheet->setCellValue("A{$rowIndex}", $category['category']);
            $categorySheet->setCellValue("B{$rowIndex}", $category['order_count']);
            $categorySheet->setCellValue("C{$rowIndex}", $category['total_quantity']);
            $categorySheet->setCellValue("D{$rowIndex}", $category['total_sales']);
            $rowIndex++;
        }

        // Auto-size columns for all sheets
        foreach ($spreadsheet->getAllSheets() as $sheet) {
            foreach (range('A', $sheet->getHighestColumn()) as $col) {
                $sheet->getColumnDimension($col)->setAutoSize(true);
            }
        }

        // Clear any previous output
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Set headers for Excel download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="business_report_' . date('Y-m-d') . '.xlsx"');
        header('Cache-Control: max-age=0');
        header('Cache-Control: max-age=1');
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
        header('Cache-Control: cache, must-revalidate');
        header('Pragma: public');

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit();

    } catch (Exception $e) {
        die("Error generating Excel file: " . $e->getMessage());
    }

} else {
    // PDF export using TCPDF
    try {
        if (ob_get_level()) {
            ob_end_clean();
        }

        $pdf = new TCPDF('L', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        $pdf->SetCreator('Moto Parts Management System');
        $pdf->SetAuthor('Admin');
        $pdf->SetTitle('Business Report');
        $pdf->SetSubject('Complete Business Report');

        $pdf->SetHeaderData('', 0, 'Business Report', 'Generated on ' . date('Y-m-d H:i:s'));
        $pdf->setFooterData();

        $pdf->SetMargins(10, PDF_MARGIN_TOP, 10);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        // All Orders
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 8);

        $html = '<h2 style="text-align: center; color: #333;">All Orders</h2>';
        $html .= '<p><strong>Export Date:</strong> ' . date('Y-m-d H:i:s') . '</p><br>';

        $html .= '<table border="1" cellpadding="3" cellspacing="0" style="width: 100%; font-size: 7px;">';
        $html .= '<thead><tr style="background-color: #f0f0f0; font-weight: bold;">';
        $html .= '<th>Order ID</th><th>Customer</th><th>Product</th><th>Qty</th><th>Price</th>';
        $html .= '<th>Order Date</th><th>Status</th><th>Payment</th><th>Method</th><th>Shipping</th>';
        $html .= '</tr></thead><tbody>';

        $totalAmount = 0;
        foreach ($orders as $order) {
            $html .= '<tr>';
            $html .= '<td>' . htmlspecialchars($order['order_id']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['customer_email']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['product_name']) . '</td>';
            $html .= '<td style="text-align: center;">' . htmlspecialchars($order['quantity']) . '</td>';
            $html .= '<td style="text-align: right;">$' . number_format($order['total_price'], 2) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['order_date']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['order_status']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['payment_status']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['payment_method']) . '</td>';
            $html .= '<td>' . htmlspecialchars($order['shipping_date'] ?? 'N/A') . '</td>';
            $html .= '</tr>';
            $totalAmount += $order['total_price'];
        }

        $html .= '</tbody><tfoot>';
        $html .= '<tr style="background-color: #f9f9f9; font-weight: bold;">';
        $html .= '<td colspan="4">Total Orders: ' . count($orders) . '</td>';
        $html .= '<td style="text-align: right;">$' . number_format($totalAmount, 2) . '</td>';
        $html .= '<td colspan="5"></td>';
        $html .= '</tr></tfoot></table>';

        $pdf->writeHTML($html, true, false, true, false, '');

        // Product Sales
        $pdf->AddPage();
        $html = '<h2 style="text-align: center; color: #333;">Product Sales Summary</h2><br>';
        
        $html .= '<table border="1" cellpadding="3" cellspacing="0" style="width: 100%;">';
        $html .= '<thead><tr style="background-color: #f0f0f0; font-weight: bold;">';
        $html .= '<th>Product Name</th><th>Order Count</th><th>Total Quantity</th><th>Total Sales</th>';
        $html .= '</tr></thead><tbody>';

        foreach ($productSales as $product) {
            $html .= '<tr>';
            $html .= '<td>' . htmlspecialchars($product['product_name']) . '</td>';
            $html .= '<td style="text-align: center;">' . $product['order_count'] . '</td>';
            $html .= '<td style="text-align: center;">' . $product['total_quantity'] . '</td>';
            $html .= '<td style="text-align: right;">$' . number_format($product['total_sales'], 2) . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';

        // Category Sales
        $html .= '<br><h2 style="text-align: center; color: #333;">Category Sales Summary</h2><br>';
        
        $html .= '<table border="1" cellpadding="3" cellspacing="0" style="width: 100%;">';
        $html .= '<thead><tr style="background-color: #f0f0f0; font-weight: bold;">';
        $html .= '<th>Category</th><th>Order Count</th><th>Total Quantity</th><th>Total Sales</th>';
        $html .= '</tr></thead><tbody>';

        foreach ($categorySales as $category) {
            $html .= '<tr>';
            $html .= '<td>' . htmlspecialchars($category['category']) . '</td>';
            $html .= '<td style="text-align: center;">' . $category['order_count'] . '</td>';
            $html .= '<td style="text-align: center;">' . $category['total_quantity'] . '</td>';
            $html .= '<td style="text-align: right;">$' . number_format($category['total_sales'], 2) . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';

        $pdf->writeHTML($html, true, false, true, false, '');

        $pdf->Output('business_report_' . date('Y-m-d') . '.pdf', 'D');
        exit();

    } catch (Exception $e) {
        die("Error generating PDF file: " . $e->getMessage());
    }
}
?>
