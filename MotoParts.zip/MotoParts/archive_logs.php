<?php
include_once("config.php");

session_start();
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Pagination setup
$limit = 20;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

// Filtering by user_id or retailer_id (optional)
$user_id_filter = isset($_GET['user_id']) ? intval($_GET['user_id']) : null;
$retailer_id_filter = isset($_GET['retailer_id']) ? intval($_GET['retailer_id']) : null;

$where_clauses = [];
if ($user_id_filter !== null) {
    $where_clauses[] = "user_id = $user_id_filter";
}
if ($retailer_id_filter !== null) {
    $where_clauses[] = "retailer_id = $retailer_id_filter";
}
$where_sql = "";
if (count($where_clauses) > 0) {
    $where_sql = "WHERE " . implode(" AND ", $where_clauses);
}

// Count total logs for pagination
$count_sql = "SELECT COUNT(*) AS total FROM action_logs $where_sql";
$count_result = $conn->query($count_sql);
$total_logs = $count_result->fetch_assoc()['total'] ?? 0;
$total_pages = ceil($total_logs / $limit);

// Fetch logs
$sql = "SELECT * FROM action_logs $where_sql ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotoParts Manager - Admin</title>
    <link rel="stylesheet" href="adminstyle.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="adminstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <script src="script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
</head>

<body>
<!----- NAVBAR ---------- NAVBAR ---------- NAVBAR ----->
<nav class="navbar">
    <div class="navdiv">
        <div class="logo">
            <img src="assets/logo.jpg" alt="MotoParts Manager">
        </div>
        <ul style="padding-top: 20px; padding-right: 20px;">
            <li><a class="hac active" href="#">Home</a></li>
            <li><a class="hac" href="about_admin.html">About</a></li>
            <li class="dropdown">
                <a class="hac" href="#" id="contactLink">Contact</a>
                <ul class="dropdown_menu" id="contactDropdown">
                    <li><p>(+63) 9298642708</p></li>
                    <li><p>mtmotoparts@gmail.com</p></li>
                </ul>
            </li>
            <div class="navbar2">
                <a href="logout.php" style="color: black; font-weight: bold;">Log Out</a> 
            </div>
        </ul>
    </div>
</nav>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const contactLink = document.getElementById("contactLink");
    const contactDropdown = document.getElementById("contactDropdown");

    if (contactLink && contactDropdown) {
        contactLink.addEventListener("click", function (event) {
            event.preventDefault();
            contactDropdown.classList.toggle("open");
        });

        // Close dropdown when clicking outside
        document.addEventListener("click", function (event) {
            if (!contactLink.contains(event.target) && !contactDropdown.contains(event.target)) {
                contactDropdown.classList.remove("open");
            }
        });
    } else {
        console.error("Contact elements not found in the DOM.");
    }
});
</script>

<!----- SUBBAR ---------- SUBBAR ---------- SUBBAR ----->
<nav class="subBar">
    <div class="subdiv">
        <ul>
            <li><a class="hac" href="product_sales.php">Product Sales Analytics</a></li>
            <li><a class="hac" href="inventory_status.php">Inventory Status</a></li>
            <li><a class="hac" href="users.php">Users</a></li>
            <li><a class="hac" href="orders.php">Orders</a></li>
            <li><a class="hac" href="business_report.php">Business Report</a></li>
            <li><a class="hac" href="archive_logs.php">Archive Logs</a></li>
        </ul>
    </div>
</nav>

<div class="content">
    <a href="adminpage.php" style="display:inline-block; margin: 10px 0; padding: 8px 15px; background-color: #6c757d; color: white; text-decoration: none; border-radius: 4px;">Back to Admin Page</a>
    <h1>Archive Logs</h1>
    <table class="custom-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Retailer ID</th>
                <th>Action Type</th>
                <th>Description</th>
                <th>Timestamp</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['user_id'] ?? 'N/A'; ?></td>
                        <td><?php echo $row['retailer_id'] ?? 'N/A'; ?></td>
                        <td><?php echo htmlspecialchars($row['action_type']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6">No logs found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>" class="btn-prev">Previous</a>
        <?php endif; ?>
        <span>Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>
        <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page + 1; ?>" class="btn-next">Next</a>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
