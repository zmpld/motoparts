<?php
require 'vendor/autoload.php';

echo "Testing packages...\n\n";

// Test PhpSpreadsheet
echo "1. Testing PhpSpreadsheet:\n";
try {
    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setCellValue('A1', 'Hello World');
    echo "   ✓ PhpSpreadsheet is working!\n";
} catch (Exception $e) {
    echo "   ✗ PhpSpreadsheet failed: " . $e->getMessage() . "\n";
}

// Test TCPDF
echo "\n2. Testing TCPDF:\n";
try {
    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, 'Hello World', 0, 1);
    echo "   ✓ TCPDF is working!\n";
} catch (Exception $e) {
    echo "   ✗ TCPDF failed: " . $e->getMessage() . "\n";
}

echo "\n✓ All packages are ready for use!\n";
echo "You can now use your export_order.php script.\n";
?>