<?php
session_start();
include 'config.php';

// Get payment status from PayRex redirect URL
$status = $_GET['status'] ?? 'unknown';

// Optional: You can retrieve tracking number if PayRex redirects with it
$tracking_number = $_GET['tracking_number'] ?? null;

switch ($status) {
    case 'success':
        $_SESSION['order_status_message'] = "✅ Your payment was successful! Thank you for your order.";
        $payment_status = 'Paid';
        break;
    case 'cancel':
        $_SESSION['order_status_message'] = "❌ Payment was cancelled. You were not charged.";
        $payment_status = 'Cancelled';
        break;
    default:
        $_SESSION['order_status_message'] = "⚠️ Payment status unknown.";
        $payment_status = 'Unknown';
        break;
}

// Optional: Update the payment_status in database (only if tracking number is passed back)
if ($tracking_number && in_array($payment_status, ['Paid', 'Cancelled'])) {
    $stmt = $conn->prepare("UPDATE orders SET payment_status = ? WHERE tracking_number = ?");
    $stmt->bind_param("ss", $payment_status, $tracking_number);
    $stmt->execute();
    $stmt->close();
}

// Redirect to customer page to show feedback
header("Location: customerpage.php");
exit();