<?php
include_once("config.php");

// Check if the form is submitted for user update
if(isset($_POST['update'])) {
    $id = intval($_POST['id']); // Convert to integer to prevent SQL injection
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    // Update user data
    $query = "UPDATE users SET 
        username='$username', 
        first_name='$first_name', 
        last_name='$last_name', 
        email='$email', 
        address='$address', 
        role='$role' 
        WHERE id=$id";

    if (mysqli_query($conn, $query)) {
        // Redirect to homepage after update
        header("Location: adminpage.php");
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

// Check if 'id' is present in the URL
if(isset($_GET['id'])) {
    $id = intval($_GET['id']); // Convert to integer to avoid SQL injection

    // Include database connection file
    include_once("config.php");

    // Fetch user data based on ID
    $result = mysqli_query($conn, "SELECT * FROM users WHERE id=$id");

    if (!$result) {
        die("Error executing query: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) > 0) {
        $user_data = mysqli_fetch_array($result);
        $username = $user_data['username'];
        $first_name = $user_data['first_name'];
        $last_name = $user_data['last_name'];
        $email = $user_data['email'];
        $address = $user_data['address'];
        $role = $user_data['role'];
    } else {
        die("No user found with the given ID.");
    }
} else {
    die("ID parameter missing.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MotoParts Manager - Edit</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
    <link rel="stylesheet" href="adminstyle.css">
</head>

<body background="assets/background.jpg">
    <div class="container" style="background: rgba(255, 255, 255, 0.8); border-radius: 10px; margin-top: 20px; padding-bottom: 75px; backdrop-filter: blur(10px);"><br>
        <h2>Edit details</h2>
        <a href="adminpage.php" class="btn btn-primary mt-3">Cancel</a>
        <br/><br/>

        <form name="update_user" method="post" action="edit.php">
            <table class="table table-bordered" style="border: 2px solid grey;">
                <tr> 
                    <td style="border: 2px solid grey;">Username</td>
                    <td  style="border: 2px solid grey;"><input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" class="form-control" required></td>
                </tr>
                <tr> 
                    <td style="border: 2px solid grey;">First Name</td>
                    <td style="border: 2px solid grey;"><input type="text" name="first_name" value="<?php echo htmlspecialchars($first_name); ?>" class="form-control" required></td>
                </tr>
                <tr> 
                    <td style="border: 2px solid grey;">Last Name</td>
                    <td style="border: 2px solid grey;"><input type="text" name="last_name" value="<?php echo htmlspecialchars($last_name); ?>" class="form-control" required></td>
                </tr>
                <tr> 
                    <td style="border: 2px solid grey;">Email</td>
                    <td style="border: 2px solid grey;"><input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" class="form-control" required></td>
                </tr>
                <tr> 
                    <td style="border: 2px solid grey;">Address</td>
                    <td style="border: 2px solid grey;"><input type="text" name="address" value="<?php echo htmlspecialchars($address); ?>" class="form-control" required></td>
                </tr>
                <tr> 
                    <td style="border: 2px solid grey;">Role</td>
                    <td style="border: 2px solid grey;">
                        <select name="role" class="form-control" required>
                            <option value="customer" <?php if($role == 'customer') echo 'selected'; ?>>Customer</option>
                            <option value="retailer" <?php if($role == 'retailer') echo 'selected'; ?>>Retailer</option>
                            <option value="admin" <?php if($role == 'admin') echo 'selected'; ?>>Admin</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td style="border: 2px solid grey;"><input type="hidden" name="id" value="<?php echo $id; ?>"></td>
                    <td style="border: 2px solid grey;"><input type="submit" name="update" value="Update" class="btn btn-success"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>

