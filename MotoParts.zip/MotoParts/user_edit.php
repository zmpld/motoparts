<?php
include_once("config.php");
include_once("archive_log.php");

session_start();
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit();
}

$user_id = intval($_GET['id']);

// Fetch user details
$stmt = $conn->prepare("SELECT id, username, email, last_name, first_name, address, role FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    header("Location: users.php");
    exit();
}
$user = $result->fetch_assoc();
$stmt->close();

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $last_name = trim($_POST['last_name']);
    $first_name = trim($_POST['first_name']);
    $address = trim($_POST['address']);
    $role = trim($_POST['role']);

    // Basic validation
    if (empty($username) || empty($email) || empty($role)) {
        $errors[] = "Username, Email, and Role are required.";
    }

    if (empty($errors)) {
        // Update user info
        $update_stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, last_name = ?, first_name = ?, address = ?, role = ? WHERE id = ?");
        $update_stmt->bind_param("ssssssi", $username, $email, $last_name, $first_name, $address, $role, $user_id);
        if ($update_stmt->execute()) {
            $success = "User information updated successfully.";

            // Log the update action
            $admin_id = $_SESSION['id'] ?? null; // Assuming admin's user id is stored in session
            $description = "Admin updated user ID $user_id info: username=$username, email=$email, last_name=$last_name, first_name=$first_name, address=$address, role=$role";
            log_action($admin_id, null, 'user_update', $description);

            // Refresh user data
            $user['username'] = $username;
            $user['email'] = $email;
            $user['last_name'] = $last_name;
            $user['first_name'] = $first_name;
            $user['address'] = $address;
            $user['role'] = $role;
        } else {
            $errors[] = "Failed to update user information.";
        }
        $update_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Admin</title>
    <link rel="stylesheet" href="adminstyle.css?v=<?php echo time(); ?>">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" href="assets/logo.jpg" type="image/x-icon">
</head>
<body>
<?php include 'admin_navbar.php'; ?>
<div class="content">
    <h1>Edit User</h1>
    <?php if ($success): ?>
        <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <div class="error-message">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="post" action="">
        <label>Username:<br>
            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
        </label><br><br>
        <label>Email:<br>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        </label><br><br>
        <label>Last Name:<br>
            <input type="text" name="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>">
        </label><br><br>
        <label>First Name:<br>
            <input type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>">
        </label><br><br>
        <label>Address:<br>
            <textarea name="address"><?php echo htmlspecialchars($user['address']); ?></textarea>
        </label><br><br>
        <label>Role:<br>
            <select name="role" required>
                <option value="customer" <?php if ($user['role'] === 'customer') echo 'selected'; ?>>Customer</option>
                <option value="retailer" <?php if ($user['role'] === 'retailer') echo 'selected'; ?>>Retailer</option>
                <option value="admin" <?php if ($user['role'] === 'admin') echo 'selected'; ?>>Admin</option>
            </select>
        </label><br><br>
        <button type="submit" class="btn-submit">Update User</button>
    </form>
    <a href="users.php" class="btn-back">Back to Users</a>
</div>
</body>
</html>
